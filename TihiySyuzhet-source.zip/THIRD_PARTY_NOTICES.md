# Third-party notices

## llama.cpp (native inference runtime)

The Android APK includes a native library built from llama.cpp at the revision recorded in `LLAMA_CPP_COMMIT.txt`. The upstream license text follows.

MIT License

Copyright (c) 2023-2026 The ggml authors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Optional Qwen2.5 GGUF model

The APK does not bundle model weights. On first launch, the app offers to download Qwen2.5-1.5B-Instruct Q4_K_M (986,048,768 bytes) over Wi-Fi, or the user may import another compatible GGUF. The quantized file is served from <https://huggingface.co/bartowski/Qwen2.5-1.5B-Instruct-GGUF/tree/9eadc66189c7641e1ddd226b8267a9119b2ce2d4>; the repository identifies the base model license as Apache-2.0. Check the model card and license before redistribution.

## Jonathan Byers character photograph

The `jonathan.jpg` avatar is a manually cropped and lightly brightened 600×600 crop of the real *Stranger Things* Season 1, Episode 6 still titled “S1E6-Jonathan & Nancy lying in bed together.” The source still is hosted by the Stranger Things Fandom gallery: <https://strangerthings.fandom.com/wiki/File:S1E6-Jonathan_%26_Nancy_lying_in_bed_together.jpg>; original image URL: <https://static.wikia.nocookie.net/strangerthings8338/images/9/9e/S1E6-Jonathan_%26_Nancy_lying_in_bed_together.jpg/revision/latest?cb=20241017152655>. It is a real episode still, not AI-generated. Copyright belongs to Netflix and the relevant rights holders; it is included only as a user-requested character avatar. Obtain permission before redistributing it in another product.
