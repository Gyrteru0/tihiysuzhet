const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const { JSDOM } = require('jsdom');

const appPath = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'app.js');
const appHtml = '<!doctype html><html lang="ru"><head><meta charset="utf-8"></head><body><div id="app" class="app-shell"><main id="view"></main><nav id="bottom-nav"></nav></div><div id="modal-root"></div><input id="avatar-file" type="file"></body></html>';
const wait = (ms = 20) => new Promise(resolve => setTimeout(resolve, ms));

function click(window, selector) {
  const node = window.document.querySelector(selector);
  assert.ok(node, `Expected an element matching ${selector}`);
  node.dispatchEvent(new window.MouseEvent('click', { bubbles: true, cancelable: true }));
}

test('deleting a generating history cancels it and allows a new chat immediately', async () => {
  const dom = new JSDOM(appHtml, { url: 'https://app.local/', runScripts: 'outside-only', pretendToBeVisual: true });
  const { window } = dom;
  const generated = [];
  const cancelled = [];
  window.Android = {
    getModelInfo: () => JSON.stringify({ available: true, name: 'test.gguf', downloading: false, progress: 0 }),
    generate: json => generated.push(JSON.parse(json)),
    cancelGeneration: requestId => cancelled.push(requestId),
  };

  try {
    window.eval(fs.readFileSync(appPath, 'utf8'));
    await wait();
    click(window, '[data-action="start-chat"]');
    let input = window.document.getElementById('message-input');
    assert.ok(input, 'the first chat should open');
    input.value = 'Первое сообщение';
    window.document.querySelector('form').dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true }));
    assert.equal(generated.length, 1, 'the first native generation should start');
    const oldRequestId = generated[0].requestId;

    click(window, '[data-action="chat-menu"]');
    click(window, '[data-action="delete-chat"]');
    click(window, '[data-action="confirm-delete-chat"]');
    assert.deepEqual(cancelled, [oldRequestId], 'deletion should cancel the active native request');
    assert.equal(JSON.parse(window.localStorage.getItem('tihiy-syuzhet-v1')).chats.length, 0, 'the deleted history should be removed');

    click(window, '[data-action="start-chat"]');
    input = window.document.getElementById('message-input');
    assert.ok(input, 'a new chat should open without waiting for the deleted generation');
    input.value = 'Новое сообщение';
    window.document.querySelector('form').dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true }));
    assert.equal(generated.length, 2, 'a new generation should be allowed immediately');
    const newRequestId = generated[1].requestId;
    assert.notEqual(oldRequestId, newRequestId, 'each generation should have a unique request ID');

    window.onNativeChunk(oldRequestId, 'STALE');
    assert.ok(!JSON.parse(window.localStorage.getItem('tihiy-syuzhet-v1')).chats[0].messages.some(message => message.text.includes('STALE')),
      'callbacks from the deleted request should be ignored');

    window.onNativeChunk(newRequestId, 'CURRENT');
    window.onNativeDone(newRequestId);
    assert.ok(JSON.parse(window.localStorage.getItem('tihiy-syuzhet-v1')).chats[0].messages.some(message => message.text.includes('CURRENT')),
      'callbacks for the current request should still be applied');
  } finally {
    window.close();
  }
});
