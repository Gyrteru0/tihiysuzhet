(() => {
  'use strict';

  const STORE_KEY = 'tihiy-syuzhet-v1';
  const MODEL_OFFER_KEY = 'tihiy-syuzhet-model-offer-v1';
  const DEFAULT_AVATAR = 'jonathan.jpg';
  const ICON = {
    spark: '<path d="m12 3 1.7 5.3L19 10l-5.3 1.7L12 17l-1.7-5.3L5 10l5.3-1.7L12 3Z"/><path d="m19 16 .8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8L19 16Z"/>',
    home: '<path d="m3 10 9-7 9 7"/><path d="M5 9.5V21h14V9.5M9 21v-6h6v6"/>',
    book: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v17H6.5A2.5 2.5 0 0 0 4 22V5.5Z"/><path d="M4 18.5A2.5 2.5 0 0 1 6.5 16H20M8 7h8M8 10h6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    user: '<circle cx="12" cy="8" r="3.5"/><path d="M4.5 21a7.5 7.5 0 0 1 15 0"/>',
    back: '<path d="m15 18-6-6 6-6"/><path d="M9 12h11"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.8-.7a8 8 0 0 1-1.7 1l-.3 1.9h-2.8l-.3-1.9a8 8 0 0 1-1.7-1l-1.8.7-1.4-2.4L7.1 15a8 8 0 0 1 0-2l-1.4-1.1 1.4-2.4 1.8.7a8 8 0 0 1 1.7-1l.3-1.9h2.8l.3 1.9a8 8 0 0 1 1.7 1l1.8-.7 1.4 2.4-1.4 1.1a8 8 0 0 1-.1 2Z"/>',
    more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
    send: '<path d="m4 4 16 8-16 8 3-8-3-8Z"/><path d="M7 12h13"/>',
    memory: '<path d="M5 4h14a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2h-9l-5 3V6a2 2 0 0 1 2-2Z"/><path d="M8 9h8M8 13h6"/>',
    edit: '<path d="m4 16.5-.8 4.3 4.3-.8L19 8.5 15.5 5 4 16.5Z"/><path d="m13.5 7 3.5 3.5M14 21h7"/>',
    heart: '<path d="M20.8 8.8c0 5.2-8.8 11-8.8 11s-8.8-5.8-8.8-11A4.8 4.8 0 0 1 12 6.2a4.8 4.8 0 0 1 8.8 2.6Z"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 14h10l1-14M9 7V4h6v3"/>',
    search: '<circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4.5 4.5"/>',
    download: '<path d="M12 3v12M7 10l5 5 5-5"/><path d="M5 20h14"/>',
    image: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="8.5" cy="9" r="1.5"/><path d="m21 15-5-5L5 20"/>',
    shield: '<path d="M12 3 20 6v5c0 5-3.4 8.5-8 10-4.6-1.5-8-5-8-10V6l8-3Z"/><path d="m9 12 2 2 4-4"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    chevron: '<path d="m9 18 6-6-6-6"/>',
    bookmark: '<path d="M6 4h12v17l-6-4-6 4V4Z"/>',
    refresh: '<path d="M20 7v5h-5"/><path d="M20 12a8 8 0 1 0 1 4"/>',
    play: '<path d="m8 5 11 7-11 7V5Z"/>',
    cloud: '<path d="M7 18h10a4 4 0 0 0 .7-7.9A6 6 0 0 0 6 9a4.5 4.5 0 0 0 1 9Z"/><path d="m9 12 3 3 3-3"/><path d="M12 15V9"/>',
    sliders: '<path d="M4 6h16M4 12h16M4 18h16"/><circle cx="9" cy="6" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="7" cy="18" r="2"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
    wand: '<path d="m15 4 5 5M4 20l11.5-11.5M5 5l.8 2.2L8 8l-2.2.8L5 11l-.8-2.2L2 8l2.2-.8L5 5ZM18 14l.8 2.2L21 17l-2.2.8L18 20l-.8-2.2L15 17l2.2-.8L18 14Z"/>',
    folder: '<path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>',
    eye: '<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6Z"/><circle cx="12" cy="12" r="2.5"/>',
    type: '<path d="M4 6V4h16v2M12 4v16M8 20h8"/>'
  };
  const svg = (name, size = 18) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" aria-hidden="true">${ICON[name] || ICON.spark}</svg>`;
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const id = () => (window.crypto?.randomUUID ? window.crypto.randomUUID() : 'id-' + Date.now() + '-' + Math.random().toString(16).slice(2));
  const now = () => new Date().toISOString();

  const SEED = {
    version: 1,
    persona: { name: 'Даша', pronouns: 'она / её', age: '', about: '', boundaries: 'Не принимай решения за меня. Не описывай мои мысли, действия и слова без моего согласия.' },
    settings: { fontSize: 18, responseLength: 'medium', temperature: 0.78, keepUserAgency: true, reduceMotion: false, roleplayStyle: true },
    characters: [{
      id: 'jonathan-au', name: 'Джонатан Байерс', age: '21', pronouns: 'он / его', role: 'Фотограф, старший брат',
      tagline: 'Тихий, внимательный и очень бережный. AU: 21+',
      tags: ['slow burn', 'уют', '1980-е', 'романтика'], avatar: DEFAULT_AVATAR,
      appearance: 'Худощавый молодой мужчина с чуть растрёпанными тёмно-каштановыми волосами и внимательным взглядом. Обычно выбирает простую потёртую куртку, свитера и вещи, в которых удобно двигаться.',
      personality: 'Наблюдательный, терпеливый, неловкий в большой компании. Доверяет медленно, но если привязался — остаётся рядом. Заботу показывает поступками: замечает детали, приносит чай, чинит сломанное, не требует объяснений.',
      backstory: 'В этой альтернативной вселенной Джонатану 21 год. Он вырос в непростых обстоятельствах, рано научился быть опорой для близких и привык не занимать много места. Фотография помогает ему замечать красоту в тихих, незаметных вещах. Его прошлое влияет на него, но не сводится к травме: у него есть юмор, любопытство и собственные мечты.',
      trauma: 'Болезненно реагирует на крик и резкие требования. Когда тревожится, замолкает и начинает возиться с фотоаппаратом. Ему нужно время, чтобы почувствовать себя в безопасности; он не обязан мгновенно раскрываться.',
      motives: 'Хочет научиться выбирать собственную жизнь, а не только заботиться обо всех вокруг. Ищет место, где можно быть несовершенным и всё равно остаться нужным.',
      voice: 'Говорит негромко, простыми словами, с сухой самоиронией. Не произносит длинных терапевтических монологов. Вместо громких обещаний предлагает конкретную помощь. В повествовании — кинематографичные детали, естественные паузы и немного внутренней сдержанности.',
      mannerisms: 'Прячет руки в рукава, перебирает крышку объектива, сначала смотрит в сторону, а потом — прямо. Улыбается редко, но искренне.',
      relationship: 'Между ним и Дашей уже есть доверие и тихая привязанность. Романтика развивается медленно, только если Даша сама этого хочет. Он уважает её темп и границы.',
      scenario: 'Поздний вечер в небольшом доме после дождя. За окном шумит ветер, на кухне остывает чай. Джонатан проявляет фотографии в самодельной тёмной комнате, а Даша приходит к нему после долгого дня.',
      plot: 'Это длинная камерная история о безопасности, близости и взрослении. Не торопи отношения и не превращай каждую сцену в драму. Пусть сюжет растёт из маленьких выборов, общих привычек, фотографий и разговоров. Оставляй Даше пространство для ответа и меняй сцену только по её репликам.',
      greeting: '*Красный свет фотолаборатории мягко ложится на стены. Джонатан отодвигает увеличитель и прислушивается к дождю за окном.*\n\n— Ты можешь просто посидеть здесь, если не хочется говорить, — негромко произносит он. — Я поставил чайник. Чай, кстати, пережил сегодняшние эксперименты лучше, чем мои фотографии.',
      instructions: 'Пиши совместную художественную ролевую сцену на русском языке. Обычно 2–5 абзацев средней длины. Разделяй действия и речь; действия можно писать курсивом между *звёздочками*. Не повторяй дословно сказанное пользователем. Не описывай мысли, действия, чувства, реплики или решения Даши — управляй только Джонатаном и окружающим миром. Не форсируй прикосновения, романтику, признания или травматические откровения. При сомнении спроси или оставь выбор открытым. Джонатан — совершеннолетний персонаж, 21 год, AU. Романтика мягкая и взаимная; никакого давления.',
      examples: '{{char}}: *Он чуть отодвигает стул, оставляя между вами свободное место.* — Не обязательно отвечать сейчас. Я могу просто включить музыку.\n{{user}}: Я боюсь, что всё испорчу.\n{{char}}: *Джонатан долго смотрит на недопечатанный снимок.* — Тогда испортим что-нибудь вместе. Бумагу, например. Она хотя бы не обидится.',
      ageGate: true, neverControlUser: true, createdAt: now()
    }],
    chats: []
  };

  function freshSeed() { return JSON.parse(JSON.stringify(SEED)); }
  function removeRetiredSeedCharacters(data) {
    if (!data || !Array.isArray(data.characters)) return false;
    const retiredIds = new Set(data.characters.filter(c => c.id === 'ilya-soft').map(c => c.id));
    if (!retiredIds.size) return false;
    data.characters = data.characters.filter(c => !retiredIds.has(c.id));
    data.chats = (Array.isArray(data.chats) ? data.chats : []).filter(chat => !retiredIds.has(chat.characterId));
    return true;
  }
  function loadDB() {
    try {
      const parsed = JSON.parse(localStorage.getItem(STORE_KEY) || 'null');
      if (parsed && Array.isArray(parsed.characters) && parsed.persona) {
        parsed.settings = Object.assign({}, SEED.settings, parsed.settings || {});
        parsed.chats = Array.isArray(parsed.chats) ? parsed.chats : [];
        if (removeRetiredSeedCharacters(parsed)) localStorage.setItem(STORE_KEY, JSON.stringify(parsed));
        return parsed;
      }
    } catch (_) {}
    const db = freshSeed();
    localStorage.setItem(STORE_KEY, JSON.stringify(db));
    return db;
  }
  let db = loadDB();
  const state = { route: 'home', activeChatId: null, editingCharId: null, newCharacter: false, modal: null, modelInfo: null, avatarTarget: null, returnRoute: 'home', generating: false, generationChatId: null, generationMessageId: null, generationRequestId: null, generationTimer: null, currentMessageId: null, toastTimer: null, progressTimer: null, search: '' };

  let fullViewportHeight = Math.max(window.innerHeight || 0, document.documentElement.clientHeight || 0);
  let viewportUpdateQueued = false;
  function updateAppViewportHeight() {
    const root = document.documentElement;
    const layoutHeight = window.innerHeight || root.clientHeight || fullViewportHeight;
    const vv = window.visualViewport;
    const visualHeight = vv ? Math.max(0, vv.height) : layoutHeight;
    let availableHeight = Math.min(layoutHeight, visualHeight);
    const nativeIme = Math.max(0, parseFloat(root.style.getPropertyValue('--native-ime-bottom')) || 0);
    if (fullViewportHeight <= 0) fullViewportHeight = layoutHeight;
    const keyboardOpen = nativeIme > 80 || fullViewportHeight - availableHeight > 110;
    if (nativeIme > 80) availableHeight = Math.min(availableHeight, fullViewportHeight - nativeIme);
    if (!keyboardOpen) { fullViewportHeight = layoutHeight; availableHeight = layoutHeight; }
    root.style.setProperty('--app-height', `${Math.max(240, Math.round(availableHeight))}px`);
    root.classList.toggle('keyboard-open', keyboardOpen);
  }
  function scheduleViewportUpdate() {
    if (viewportUpdateQueued) return;
    viewportUpdateQueued = true;
    requestAnimationFrame(() => { viewportUpdateQueued = false; updateAppViewportHeight(); });
  }
  window.addEventListener('resize', scheduleViewportUpdate);
  window.addEventListener('orientationchange', () => setTimeout(() => {
    if (!(parseFloat(document.documentElement.style.getPropertyValue('--native-ime-bottom')) > 80)) {
      fullViewportHeight = Math.max(window.innerHeight || 0, document.documentElement.clientHeight || 0);
    }
    updateAppViewportHeight();
  }, 250));
  window.visualViewport?.addEventListener('resize', scheduleViewportUpdate);
  window.visualViewport?.addEventListener('scroll', scheduleViewportUpdate);
  window.addEventListener('native-ime-insets', scheduleViewportUpdate);
  document.addEventListener('focusin', scheduleViewportUpdate);
  document.addEventListener('focusout', () => setTimeout(scheduleViewportUpdate, 120));
  updateAppViewportHeight();

  function saveDB() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(db)); }
    catch (e) { toast('Не хватило места для сохранения. Попробуй уменьшить аватар.'); }
  }
  function getChar(charId) { return db.characters.find(c => c.id === charId) || db.characters[0]; }
  function getChat(chatId = state.activeChatId) { return db.chats.find(c => c.id === chatId) || null; }
  function chatChar(chat) { return chat ? getChar(chat.characterId) : db.characters[0]; }
  function modelInfo() {
    if (state.modelInfo) return state.modelInfo;
    try {
      if (window.Android && typeof Android.getModelInfo === 'function') return JSON.parse(Android.getModelInfo());
    } catch (_) {}
    return { available: false, name: '', downloading: false, progress: 0 };
  }
  function hasNativeModel() {
    const m = modelInfo();
    return !!(window.Android && m.available);
  }
  function refreshModelInfo() {
    try {
      if (window.Android && Android.getModelInfo) state.modelInfo = JSON.parse(Android.getModelInfo());
      else state.modelInfo = { available: false, name: '', downloading: false, progress: 0 };
    } catch (_) { state.modelInfo = { available: false, name: '', downloading: false, progress: 0 }; }
    return state.modelInfo;
  }
  function avatarHtml(character, cls = '') {
    const src = character?.avatar || '';
    if (src) return `<div class="avatar ${cls}"><img src="${esc(src)}" alt="" onerror="this.parentElement.innerHTML='${esc((character?.name || '?').slice(0,1))}'"></div>`;
    return `<div class="avatar ${cls}">${esc((character?.name || '✦').trim().slice(0,1).toUpperCase())}</div>`;
  }
  function initials(name) { return esc((name || '✦').trim().slice(0,1).toUpperCase()); }
  function tagList(tags) { return (tags || []).slice(0,4).map(tag => `<span class="tag">${esc(tag)}</span>`).join(''); }
  function formatText(text) {
    const safe = esc(text || '');
    return safe.replace(/\*([^*\n]+)\*/g, '<em>$1</em>').replace(/\n/g, '<br>');
  }
  function dateLabel(value) {
    try { return new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'short' }).format(new Date(value)); } catch (_) { return ''; }
  }
  function topbar(options = {}) {
    return `<header class="topbar">
      <div class="brand"><div class="brand-mark">${svg('spark',21)}</div><div><div class="brand-name">Тихий сюжет</div><span class="brand-sub">истории остаются рядом</span></div></div>
      <div class="top-actions"><span class="status-pill"><i class="status-dot"></i> офлайн</span><button class="icon-btn" data-action="settings" aria-label="Настройки">${svg('settings')}</button></div>
    </header>`;
  }
  function renderNav() {
    const nav = document.getElementById('bottom-nav');
    const visible = ['home','library','profile'].includes(state.route);
    nav.classList.toggle('hide', !visible);
    if (!visible) return;
    nav.innerHTML = `
      <button class="nav-item ${state.route === 'home' ? 'active' : ''}" data-action="goto-home">${svg('home',19)}<span>Истории</span></button>
      <button class="nav-item ${state.route === 'library' ? 'active' : ''}" data-action="goto-library">${svg('book',19)}<span>Персонажи</span></button>
      <button class="nav-item create-nav" data-action="new-character" aria-label="Создать персонажа">${svg('plus',22)}</button>
      <button class="nav-item ${state.route === 'profile' ? 'active' : ''}" data-action="goto-profile">${svg('user',19)}<span>Я</span></button>`;
  }
  function renderHome() {
    const view = document.getElementById('view');
    const first = db.characters[0];
    const recent = [...db.chats].sort((a,b) => (b.updatedAt || '').localeCompare(a.updatedAt || '')).slice(0,2);
    const model = refreshModelInfo();
    const engineCopy = model.available
      ? `Модель ${esc(model.name || 'GGUF')} сохранена на устройстве. После первого запуска диалога ответы будут рождаться прямо на телефоне.`
      : 'Без модели истории и персонажи тоже работают. Добавь компактную языковую модель один раз — и дальше можно общаться в авиарежиме.';
    view.innerHTML = `<section class="screen">
      ${topbar()}
      <div class="kicker">твоё место для историй</div>
      <h1 class="hero-title">Здесь можно<br>не торопиться.</h1>
      <p class="hero-copy">Создавай героев, береги детали сюжета и возвращайся к своим историям — даже без сети.</p>
      <div class="offline-card"><div class="offline-icon">${svg('shield',17)}</div><div class="flex1"><strong>${model.available ? 'Модель на устройстве' : 'Сюжет остаётся локальным'}</strong><p>${engineCopy}</p><button class="text-link" data-action="model-settings">${model.available ? 'Настроить локальный ИИ' : 'Подготовить ИИ к офлайну'} ${svg('chevron',12)}</button></div></div>
      <div class="feature-card" data-action="start-chat" data-char="${esc(first.id)}">
        <img class="feature-image" src="${esc(first.avatar || DEFAULT_AVATAR)}" alt="">
        <div class="feature-content"><div class="kicker">медленный сюжет · AU 21+</div><h2>${esc(first.name)}</h2><p>${esc(first.tagline)}</p><button class="btn small warm" data-action="start-chat" data-char="${esc(first.id)}">${svg('play',14)} Начать историю</button></div>
      </div>
      <div class="section-head"><h2>Продолжить</h2><button class="more-link" data-action="goto-library">Все сцены ${svg('chevron',13)}</button></div>
      ${recent.length ? `<div class="character-list">${recent.map(chat => {
        const ch = chatChar(chat); const last = chat.messages?.[chat.messages.length-1];
        return `<button class="character-card" data-action="open-chat" data-chat="${esc(chat.id)}" style="text-align:left;width:100%">${avatarHtml(ch)}<div class="character-meta"><h3>${esc(chat.title || ch.name)}</h3><p>${esc(last?.text || ch.tagline).slice(0,100)}</p><div class="card-tags"><span class="tag">${dateLabel(chat.updatedAt || chat.createdAt)}</span><span class="tag">${chat.messages?.length || 0} реплик</span></div></div>${svg('chevron',17)}</button>`;
      }).join('')}</div>` : `<div class="empty-card"><div class="empty-icon">${svg('book',19)}</div><h3>Первая сцена ждёт тебя</h3><p>Начни с Джонатаном или собери своего героя с нуля — с собственным миром и вступлением.</p><button class="btn small" data-action="start-chat" data-char="${esc(first.id)}">${svg('play',14)} Начать историю</button></div>`}
      <div class="section-head"><h2>Быстрые действия</h2></div>
      <div class="quick-grid">
        <button class="quick-card" data-action="new-character"><span class="quick-icon">${svg('plus',18)}</span><span>Создать героя<small>подробная карточка</small></span></button>
        <button class="quick-card" data-action="goto-profile"><span class="quick-icon">${svg('user',18)}</span><span>Моя персона<small>кто ты в истории</small></span></button>
      </div>
    </section>`;
  }
  function renderLibrary() {
    const view = document.getElementById('view');
    const query = state.search.trim().toLowerCase();
    const chars = db.characters.filter(c => !query || [c.name,c.tagline,c.role,...(c.tags||[])].join(' ').toLowerCase().includes(query));
    view.innerHTML = `<section class="screen">
      ${topbar()}
      <div class="kicker">твои миры</div><h1 class="hero-title">Персонажи</h1><p class="hero-copy">Каждого героя можно настроить до мельчайших деталей — или переписать с нуля.</p>
      <label class="search-wrap">${svg('search',18)}<input id="character-search" type="search" autocomplete="off" placeholder="Имя, настроение, сюжет…" value="${esc(state.search)}"></label>
      <div class="section-head"><h2>Моя библиотека</h2><button class="more-link" data-action="new-character">${svg('plus',14)} Создать</button></div>
      ${chars.length ? `<div class="character-list">${chars.map(ch => `<div class="character-card">${avatarHtml(ch)}<div class="character-meta" data-action="start-chat" data-char="${esc(ch.id)}"><h3>${esc(ch.name)} <span class="badge">${esc(ch.age || '—')}</span></h3><p>${esc(ch.tagline || ch.role || '')}</p><div class="card-tags">${tagList(ch.tags)}</div></div><button class="more-dot" data-action="character-menu" data-char="${esc(ch.id)}" aria-label="Действия">${svg('more',18)}</button></div>`).join('')}</div>` : `<div class="empty-card"><div class="empty-icon">${svg('search',18)}</div><h3>Ничего не нашлось</h3><p>Попробуй другое слово или создай новую карточку персонажа.</p><button class="btn small" data-action="new-character">${svg('plus',14)} Создать персонажа</button></div>`}
      <div class="section-head"><h2>Истории</h2></div>
      ${db.chats.length ? `<div class="character-list">${[...db.chats].sort((a,b)=>(b.updatedAt||'').localeCompare(a.updatedAt||'')).map(chat => { const ch=chatChar(chat); const last=chat.messages?.[chat.messages.length-1]; return `<button class="character-card" data-action="open-chat" data-chat="${esc(chat.id)}" style="text-align:left;width:100%">${avatarHtml(ch,'tiny')}<div class="character-meta"><h3>${esc(chat.title || ch.name)}</h3><p>${esc(last?.text || ch.tagline).slice(0,90)}</p></div><span class="tag">${dateLabel(chat.updatedAt||chat.createdAt)}</span></button>`;}).join('')}</div>` : `<p class="small-copy">Пока пусто. Начни разговор — он сохранится здесь автоматически.</p>`}
    </section>`;
  }
  function renderMessage(msg, index, chat) {
    const user = msg.role === 'user';
    const html = formatText(msg.text || '');
    const time = msg.time ? new Intl.DateTimeFormat('ru-RU',{hour:'2-digit',minute:'2-digit'}).format(new Date(msg.time)) : '';
    const isLastAssistant = !user && index === chat.messages.length - 1;
    return `<article class="message-row ${user?'user':''}" data-message-row="${esc(msg.id)}">
      <div class="message-bubble" data-message-content="${esc(msg.id)}">${html || (msg.generating ? '<span class="generating-indicator"><i></i><i></i><i></i></span>' : '')}</div>
      <div class="message-meta"><span>${user ? esc(db.persona.name || 'Ты') : esc(chatChar(chat).name.split(' ')[0])}</span>${time ? `<span>·</span><span>${esc(time)}</span>`:''}${msg.pinned ? `<span>· ${svg('bookmark',10)} в памяти</span>`:''}</div>
      ${!msg.generating ? `<div class="message-actions">
        <button class="message-action" data-action="message-menu" data-message="${esc(msg.id)}" aria-label="Действия с репликой">${svg('more',14)}</button>
        ${isLastAssistant ? `<button class="message-action" data-action="regenerate" data-message="${esc(msg.id)}" aria-label="Перегенерировать">${svg('refresh',13)}<span>ещё ответ</span></button>` : ''}
      </div>` : ''}
    </article>`;
  }
  function renderChat() {
    const view = document.getElementById('view');
    const chat = getChat();
    if (!chat) { state.route = 'home'; render(); return; }
    const ch = chatChar(chat); const model = refreshModelInfo();
    const latest = chat.messages?.[chat.messages.length-1];
    view.innerHTML = `<section class="screen chat-screen">
      <header class="chat-header">
        <button class="icon-btn" data-action="back-from-chat" aria-label="Назад">${svg('back',19)}</button>
        ${avatarHtml(ch,'tiny')}
        <div class="chat-title"><strong>${esc(chat.title || ch.name)}</strong><small>${model.available ? 'локальная модель · данные остаются на телефоне' : 'режим без модели · ответы-сценарии'}</small></div>
        <button class="icon-btn" data-action="open-memory" aria-label="Память и сюжет">${svg('memory',17)}</button>
        <button class="icon-btn" data-action="chat-menu" aria-label="Меню">${svg('more',18)}</button>
      </header>
      <div class="message-list" id="message-list">
        ${chat.summary ? `<div class="scene-note">${svg('bookmark',12)} ${esc(chat.summary)}</div>` : ''}
        ${(chat.messages || []).map((m,i)=>renderMessage(m,i,chat)).join('')}
      </div>
      <div class="chat-composer-wrap">
        <form class="composer" id="composer-form">
          <textarea id="message-input" rows="1" placeholder="Напиши реплику…" aria-label="Сообщение" ${state.generating?'disabled':''}></textarea>
          <button class="send-btn" type="submit" aria-label="Отправить" ${state.generating?'disabled':''}>${state.generating?'<span class="generating-indicator"><i></i><i></i><i></i></span>':svg('send',19)}</button>
        </form>
        <div class="composer-tools">
          <button class="chip" data-action="persona-edit">${svg('user',13)} ${esc(db.persona.name || 'Моя персона')}</button>
          <button class="chip accent" data-action="model-settings"><i class="chip-dot" style="background:${model.available?'#a9c6ad':'#b9a0d8'}"></i>${model.available ? esc((model.name || 'локальная модель').replace(/\.gguf$/i,'')) : 'Сценарный режим'}</button>
          <button class="chip ${db.settings.roleplayStyle !== false ? 'accent' : ''}" data-action="toggle-rp-style" aria-pressed="${db.settings.roleplayStyle !== false}"><i class="chip-dot" style="background:${db.settings.roleplayStyle !== false ? '#cbb8ff' : '#777581'}"></i>RP-стиль ${db.settings.roleplayStyle !== false ? 'вкл' : 'выкл'}</button>
          <button class="chip" data-action="open-memory">${svg('bookmark',12)} память ${chat.facts?.length ? `· ${chat.facts.length}`:''}</button>
          <button class="chip" data-action="chat-menu">${svg('sliders',13)} сцена</button>
        </div>
      </div>
    </section>`;
    const list = document.getElementById('message-list');
    if (list) list.scrollTop = list.scrollHeight;
    const input = document.getElementById('message-input');
    if (input) {
      input.style.fontSize = '16px';
      input.addEventListener('input', () => { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight,132) + 'px'; });
      input.addEventListener('keydown', ev => { if (ev.key === 'Enter' && !ev.shiftKey) { ev.preventDefault(); sendCurrentMessage(); } });
      const form = document.getElementById('composer-form');
      form.addEventListener('submit', ev => { ev.preventDefault(); sendCurrentMessage(); });
    }
    document.documentElement.style.setProperty('--font-chat', `${Number(db.settings.fontSize) || 18}px`);
  }
  function formField(label, key, value, options = {}) {
    const type = options.type || 'textarea';
    const wide = options.wide ? ' style="grid-column:1 / -1"' : '';
    const placeholder = options.placeholder ? ` placeholder="${esc(options.placeholder)}"` : '';
    const required = options.required ? ' required' : '';
    const hint = options.hint ? `<span class="hint">${esc(options.hint)}</span>` : '';
    const labelHtml = `<label>${esc(label)}${options.optional ? ' <span class="optional">необязательно</span>' : ''}</label>`;
    if (type === 'select') return `<div class="field"${wide}>${labelHtml}<select data-field="${esc(key)}">${options.choices.map(([v,l])=>`<option value="${esc(v)}" ${String(value)===String(v)?'selected':''}>${esc(l)}</option>`).join('')}</select>${hint}</div>`;
    if (type === 'input') return `<div class="field"${wide}>${labelHtml}<input data-field="${esc(key)}" value="${esc(value)}"${placeholder}${required} ${options.inputType?`type="${esc(options.inputType)}"`:''}>${hint}</div>`;
    return `<div class="field"${wide}>${labelHtml}<textarea data-field="${esc(key)}" class="${options.tall?'tall':''} ${options.extraTall?'extra-tall':''}"${placeholder}${required}>${esc(value)}</textarea>${hint}</div>`;
  }
  function switchRow(label, description, key, checked) {
    return `<div class="switch-row"><div class="switch-copy"><strong>${esc(label)}</strong><small>${esc(description)}</small></div><label class="switch"><input type="checkbox" data-check="${esc(key)}" ${checked?'checked':''}><span></span></label></div>`;
  }
  function renderEditor() {
    const view = document.getElementById('view');
    const character = state.newCharacter ? {
      id: id(), name:'', age:'18', pronouns:'он / его', role:'', tagline:'', tags:[], avatar:'', appearance:'', personality:'', backstory:'', trauma:'', motives:'', voice:'', mannerisms:'', relationship:'', scenario:'', plot:'', greeting:'', instructions:'', examples:'', ageGate:true, neverControlUser:true
    } : getChar(state.editingCharId);
    state.editorDraft = state.editorDraft || JSON.parse(JSON.stringify(character));
    const c = state.editorDraft;
    view.innerHTML = `<section class="editor-screen">
      <header class="editor-header"><button class="icon-btn" data-action="cancel-editor" aria-label="Назад">${svg('back',19)}</button><h1>${state.newCharacter?'Новый персонаж':'Редактировать персонажа'}</h1><button class="icon-btn" data-action="editor-help" aria-label="Подсказка">${svg('info',17)}</button></header>
      <div class="editor-scroll" id="editor-scroll">
        <div class="form-section"><div class="form-section-head"><span class="section-icon">${svg('image',15)}</span>Образ и основа</div>
          <div class="avatar-picker">${avatarHtml(c,'large')}<button class="btn secondary small" data-action="pick-avatar">${svg('image',14)} Выбрать аватар</button></div>
          <div class="form-grid">
            ${formField('Имя персонажа','name',c.name,{type:'input',required:true,placeholder:'Например, Джонатан'})}
            ${formField('Возраст','age',c.age,{type:'input',inputType:'number',required:true,placeholder:'18'})}
            ${formField('Местоимения','pronouns',c.pronouns,{type:'input',placeholder:'он / его'})}
            ${formField('Роль / занятие','role',c.role,{type:'input',placeholder:'Фотограф, студент…'})}
            ${formField('Короткое описание','tagline',c.tagline,{type:'input',wide:true,placeholder:'Какое чувство обещает эта история?'})}
            ${formField('Теги через запятую','tags',(c.tags||[]).join(', '),{type:'input',wide:true,placeholder:'уют, тайна, slow burn'})}
          </div><p class="form-note">Аватар хранится локально в приложении. Изображение автоматически уменьшается, чтобы занимать меньше места.</p>
        </div>
        <div class="form-section"><div class="form-section-head"><span class="section-icon">${svg('user',15)}</span>Характер и внутренний мир</div>
          ${formField('Внешность','appearance',c.appearance,{wide:true,placeholder:'Черты, одежда, жесты, детали — то, что легко представить.'})}
          ${formField('Личность — через поведение','personality',c.personality,{wide:true,tall:true,placeholder:'Не только прилагательные: как он проявляет заботу, чего избегает, как реагирует на стресс?'})}
          ${formField('Предыстория','backstory',c.backstory,{wide:true,tall:true,placeholder:'Прошлое, важные события, отношения и факты, которые персонаж знает.'})}
          <div class="form-grid">${formField('Уязвимости и триггеры','trauma',c.trauma,{placeholder:'Что делает его осторожным? Как он бережёт себя?'})}${formField('Цели и мотивация','motives',c.motives,{placeholder:'Чего он хочет сейчас и к чему стремится?'})}</div>
          <div class="form-grid">${formField('Манера речи','voice',c.voice,{placeholder:'Темп, слова, чувство юмора, длина реплик.'})}${formField('Привычки и жесты','mannerisms',c.mannerisms,{placeholder:'Маленькие повторяющиеся детали.'})}</div>
        </div>
        <div class="form-section"><div class="form-section-head"><span class="section-icon">${svg('book',15)}</span>Сюжет и отношения</div>
          ${formField('Отношения с моей персоной','relationship',c.relationship,{wide:true,placeholder:'Незнакомцы, друзья, пара, бывшие… Как развиваются отношения?'})}
          ${formField('Сцена, с которой начинается история','scenario',c.scenario,{wide:true,tall:true,placeholder:'Место, время, атмосфера, что происходит прямо сейчас.'})}
          ${formField('Отдельный сюжет / канон','plot',c.plot,{wide:true,extraTall:true,placeholder:'Большая арка, события, правила мира, персонажи второго плана и темы, к которым вы хотите вернуться.'})}
          ${formField('Первое сообщение персонажа','greeting',c.greeting,{wide:true,extraTall:true,placeholder:'Сильное вступление: действие + голос + открытая возможность ответить.'})}
        </div>
        <div class="form-section"><div class="form-section-head"><span class="section-icon">${svg('wand',15)}</span>Стиль и правила ролевой игры</div>
          ${formField('Дополнительные инструкции персонажу','instructions',c.instructions,{wide:true,extraTall:true,placeholder:'Особенности именно этого героя, ограничения темы или стилистические детали…',hint:'Общие правила уже действуют во всех чатах: действия и описания — курсивом, речь — отдельной обычной репликой. Здесь только индивидуальные уточнения персонажа.'})}
          ${formField('Примеры диалога','examples',c.examples,{wide:true,tall:true,placeholder:'{{char}}: …\n{{user}}: …\nПокажите голос персонажа на примерах.'})}
          ${switchRow('Не писать за меня','По умолчанию персонаж не придумывает мои слова, мысли и действия.','neverControlUser',c.neverControlUser !== false)}
          ${switchRow('Персонаж совершеннолетний','Для романтического режима персонажу должно быть 18+. Указанный возраст сохраняется в карточке.','ageGate',c.ageGate !== false)}
          <p class="form-note">Для Джонатана в приложении уже создана взрослая AU-версия (21+). Романтический темп, прикосновения и важные события остаются на твоё усмотрение.</p>
        </div>
        <div class="form-section"><div class="form-section-head"><span class="section-icon">${svg('shield',15)}</span>Локальность и бережные границы</div>
          <p class="small-copy">Карточки и переписки сохраняются в хранилище приложения на этом телефоне. Облачной синхронизации нет. Не добавляй в сюжеты пароли, адреса и другие данные, которые не хочется хранить на устройстве.</p>
        </div>
      </div>
      <footer class="editor-footer"><button class="btn secondary" data-action="save-character">Сохранить</button><button class="btn" data-action="save-and-start">${svg('play',14)} Сохранить и начать</button></footer>
    </section>`;
    document.querySelectorAll('[data-field]').forEach(el => el.addEventListener('input', () => { state.editorDraft[el.dataset.field] = el.value; }));
    document.querySelectorAll('[data-check]').forEach(el => el.addEventListener('change', () => { state.editorDraft[el.dataset.check] = el.checked; }));
  }
  function renderProfile() {
    const p = db.persona;
    const view = document.getElementById('view');
    view.innerHTML = `<section class="screen">
      ${topbar()}
      <div class="kicker">твоя роль в историях</div><h1 class="hero-title">Моя персона</h1><p class="hero-copy">Опиши себя один раз — персонажи смогут опираться на эти детали, не решая за тебя, что делать.</p>
      <div class="profile-hero" style="margin-top:20px"><div class="avatar">${initials(p.name)}</div><div class="flex1"><h2>${esc(p.name || 'Имя пока пустое')}</h2><p>${esc(p.pronouns || 'Местоимения не указаны')} · только на этом устройстве</p></div><button class="icon-btn" data-action="persona-edit">${svg('edit',17)}</button></div>
      <div class="section-head"><h2>Настройки чтения</h2></div>
      <div class="form-section">
        <div class="setting-row"><span class="setting-icon">${svg('type',17)}</span><div class="setting-copy"><strong>Размер текста в чате</strong><small>Средний — как в твоём примере. Меняется отдельно от системного шрифта.</small></div><span class="setting-value" id="font-value">${Number(db.settings.fontSize)||18}px</span></div>
        <div class="slider-row"><span>Аа</span><input id="font-size-slider" type="range" min="15" max="22" step="1" value="${Number(db.settings.fontSize)||18}"><span style="font-size:15px">Аа</span></div>
        <div class="divider"></div>
        <div class="setting-row"><span class="setting-icon">${svg('sliders',17)}</span><div class="setting-copy"><strong>Длина ответа</strong><small>Для локальной модели. Короткие ответы экономят память и время.</small></div></div>
        <div class="row" style="flex-wrap:wrap">${[['short','Короткая'],['medium','Средняя'],['long','Подробная']].map(([v,l])=>`<button class="chip ${db.settings.responseLength===v?'accent':''}" data-action="set-length" data-value="${v}">${l}</button>`).join('')}</div>
        <div class="divider"></div>
        <div class="switch-row"><div class="switch-copy"><strong>Живой RP-стиль</strong><small>Вариативнее действия и реплики во всех чатах. Это настройка подсказки, не дообучение модели.</small></div><label class="switch"><input id="rp-style-toggle" type="checkbox" aria-label="Живой RP-стиль" ${db.settings.roleplayStyle !== false ? 'checked' : ''}><span></span></label></div>
      </div>
      <div class="section-head"><h2>Данные и офлайн</h2></div>
      <div class="form-section">
        <button class="setting-row" style="width:100%;text-align:left;background:none" data-action="model-settings"><span class="setting-icon">${svg('download',17)}</span><span class="setting-copy"><strong>Локальная языковая модель</strong><small>${modelInfo().available ? `На устройстве: ${esc(modelInfo().name || 'GGUF')}` : 'Скачать или импортировать GGUF, пока доступна сеть.'}</small></span>${svg('chevron',16)}</button>
        <button class="setting-row" style="width:100%;text-align:left;background:none" data-action="export-backup"><span class="setting-icon">${svg('cloud',17)}</span><span class="setting-copy"><strong>Экспортировать резервную копию</strong><small>Персонажи, истории, память и настройки — в JSON-файл.</small></span>${svg('chevron',16)}</button>
        <button class="setting-row" style="width:100%;text-align:left;background:none" data-action="import-backup"><span class="setting-icon">${svg('folder',17)}</span><span class="setting-copy"><strong>Восстановить копию</strong><small>Импортируй JSON, сохранённый ранее.</small></span>${svg('chevron',16)}</button>
      </div>
      <div class="offline-card"><div class="offline-icon">${svg('shield',17)}</div><div><strong>Без аккаунта и облака</strong><p>Сообщения не отправляются на сервер. Интернет нужен только для первоначальной загрузки модели, если ты решишь ей пользоваться.</p></div></div>
      <p class="small-copy" style="margin-top:18px;text-align:center">Тихий сюжет · локальные ролевые истории · версия 1.0.5</p>
    </section>`;
  }
  function render() {
    const view = document.getElementById('view');
    view.classList.toggle('chat-view', state.route === 'chat');
    if (state.renderedRoute !== state.route) { view.scrollTop = 0; state.renderedRoute = state.route; }
    document.documentElement.style.setProperty('--font-chat', `${Number(db.settings.fontSize)||18}px`);
    if (state.route === 'home') renderHome();
    else if (state.route === 'library') renderLibrary();
    else if (state.route === 'chat') renderChat();
    else if (state.route === 'editor') renderEditor();
    else if (state.route === 'profile') renderProfile();
    else renderHome();
    renderNav(); renderModal();
  }
  function go(route) { state.route = route; state.modal = null; state.editorDraft = null; document.getElementById('view').scrollTop = 0; render(); }
  function makeChat(characterId) {
    if (state.generating) { toast('Подожди, пока завершится локальная генерация.'); return; }
    const ch = getChar(characterId);
    if (!ch) return;
    const chat = { id: id(), characterId: ch.id, title: ch.name, createdAt: now(), updatedAt: now(), summary: '', facts: [], messages: [{id:id(),role:'assistant',text:ch.greeting || `*${ch.name} внимательно смотрит на тебя.*\n\n— Рад, что ты пришла. С чего начнём?`,time:now()}] };
    db.chats.unshift(chat); saveDB(); state.activeChatId = chat.id; state.generating = false; state.returnRoute = state.route === 'chat' ? 'home' : state.route; go('chat');
  }
  function openChat(chatId) {
    if (state.generating && state.generationChatId !== chatId) { toast('Сначала дождись ответа в открытой сцене.'); return; }
    state.returnRoute = state.route === 'chat' ? 'home' : state.route;
    state.activeChatId = chatId; state.generating = state.generationChatId === chatId; go('chat');
  }
  function openEditor(charId = null) {
    state.newCharacter = !charId; state.editingCharId = charId; state.editorDraft = null; state.returnRoute = state.route; go('editor');
  }
  function getEditorValues() {
    const c = state.editorDraft;
    document.querySelectorAll('[data-field]').forEach(el => { c[el.dataset.field] = el.value; });
    document.querySelectorAll('[data-check]').forEach(el => { c[el.dataset.check] = el.checked; });
    c.tags = String(c.tags || '').split(',').map(s=>s.trim()).filter(Boolean).slice(0,14);
    c.age = String(c.age || '').trim();
    return c;
  }
  function saveCharacter(start) {
    const c = getEditorValues();
    if (!c.name.trim()) { toast('Добавь имя персонажа.'); document.querySelector('[data-field="name"]')?.focus(); return; }
    if (c.age && Number(c.age) < 18 && c.ageGate) { toast('Для романтического режима укажи совершеннолетний возраст или отключи эту настройку.'); return; }
    c.name = c.name.trim(); c.updatedAt = now();
    if (state.newCharacter) { c.id = c.id || id(); c.createdAt = now(); db.characters.unshift(c); }
    else { const at = db.characters.findIndex(x=>x.id===c.id); if (at >= 0) db.characters[at] = c; }
    saveDB(); state.newCharacter = false; state.editingCharId = null; state.editorDraft = null;
    if (start) makeChat(c.id); else { state.route = 'library'; render(); toast('Персонаж сохранён.'); }
  }
  function createSystemPrompt(ch, chat, previous = []) {
    const p = db.persona;
    const facts = (chat.facts || []).map(x=>`• ${x}`).join('\n');
    const history = previous.slice(-4).map(m => `${m.role==='user' ? (p.name || 'Пользователь') : ch.name}: ${String(m.text || '').slice(-420)}`).join('\n');
    const lengthGuide = db.settings.responseLength === 'short'
      ? 'КОРОТКО: обычно 1–2 коротких предложения, примерно 70–180 символов; один ясный ход и пауза для пользователя.'
      : db.settings.responseLength === 'long'
        ? 'ПОДРОБНО: до 2 коротких абзацев, примерно 250–600 символов; только если сцене действительно нужно развитие.'
        : 'СРЕДНЕ: обычно 1–3 коротких предложения, ориентир 100–300 символов; не растягивай простую реакцию.';
    const roleplayStyleGuide = db.settings.roleplayStyle !== false
      ? 'ЖИВАЯ РЕЧЬ: отвечай адресно на последнюю реплику, держись конкретной детали сцены и голоса персонажа. Пиши естественно и компактно: чаще одна реплика, иногда один короткий жест *между звёздочками*; не ставь жест перед каждым ответом. Меняй ритм и длину фраз, не пересказывай сказанное и не объясняй очевидное. Вопрос в конце — только когда он естественно продолжает сцену, не автоматически. Разговорные паузы и тире используй умеренно; не копируй фразы из корпуса.'
      : 'ЖИВОЙ RP-СТИЛЬ ВЫКЛЮЧЕН: пиши проще и прямее, но оставайся персонажем сцены, отвечай по существу и сохраняй все правила автономии.';
    const parts = [
      'РОЛЬ: Ты — персонаж интерактивной истории, а не универсальный помощник. Отвечай за персонажа и уместных NPC, сразу реагируй на последнюю реплику. Не упоминай модель и не выходи из сцены без просьбы.',
      'ФОРМАТ: По умолчанию русский язык и настоящее время. Действие или заметная реакция — *курсивом* только когда они уместны; прямая речь начинается с тире. Не обязан каждый раз описывать жест, ставить кавычки или писать действие перед репликой.',
      'БЕЗ СЛУЖБЫ ПОДДЕРЖКИ: никогда не отвечай шаблоном «Как я могу помочь тебе сегодня?» или его вариантами вроде «Чем могу помочь?». На приветствие отвечай от лица персонажа, с живой реакцией на сцену; не предлагай помощь, не начинай с «это отличный вопрос» и не заканчивай формальным приглашением задать ещё вопросы.',
      'АВТОНОМИЯ: Пиши только за персонажа, NPC и окружение. Не выдумывай за пользователя его слова, действия, мысли, чувства, телесные реакции, согласие или решения. Не завершай за него важный выбор: покажи реакцию персонажа и оставь естественное место для ответа.',
      'ЖИВОЙ ХАРАКТЕР: Сохраняй голос, привычки, сильные и слабые стороны карточки. Персонаж знает только то, что видел, слышал или узнал в истории. Учитывай время, место, предметы, травмы, обещания, отношения и уже установленные факты. Изменения характера и доверия происходят постепенно.',
      'РИТМ: Продвигай сцену небольшими причинно-следственными шагами. Используй естественные паузы, подтекст и точные детали поведения; сенсорные описания — только когда они помогают моменту. Не пересказывай реплику пользователя, не повторяй одинаковые жесты, не добавляй случайные крупные повороты, не прыгай во времени и не заканчивай каждый ответ вопросом. Не используй заголовки и списки, если их не попросили.',
      'ГРАНИЦЫ: Учитывай явно заданные предпочтения и отказы; романтика — только между совершеннолетними персонажами и без давления. Если сообщение начинается с [Вне сцены:], ответь кратко как соавтор, не заставляя персонажа слышать эти инструкции.',
      lengthGuide,
      roleplayStyleGuide,
      `ПЕРСОНАЖ: ${ch.name}, ${ch.age ? ch.age+' лет' : 'возраст не указан'}; ${ch.pronouns || ''}. ${ch.role || ''}`, 
      `КРАТКО: ${ch.tagline || ''}`,
      `ВНЕШНОСТЬ: ${ch.appearance || ''}`,
      `ЛИЧНОСТЬ: ${ch.personality || ''}`,
      `ПРЕДЫСТОРИЯ: ${ch.backstory || ''}`,
      `УЯЗВИМОСТИ: ${ch.trauma || ''}`,
      `МОТИВАЦИЯ: ${ch.motives || ''}`,
      `ГОЛОС И МАНЕРА: ${ch.voice || ''} ${ch.mannerisms || ''}`,
      `ОТНОШЕНИЯ С ПЕРСОНОЙ ПОЛЬЗОВАТЕЛЯ: ${ch.relationship || ''}`,
      `СЦЕНА: ${ch.scenario || ''}`,
      `ДЛИННАЯ АРКА / КАНОН: ${ch.plot || ''}`,
      `ИНДИВИДУАЛЬНЫЕ ДОПОЛНИТЕЛЬНЫЕ ИНСТРУКЦИИ: ${ch.instructions || ''}`,
      `ПОЛЬЗОВАТЕЛЬСКАЯ ПЕРСОНА: ${p.name || 'Пользователь'}; ${p.pronouns || ''}. ${p.about || ''} Границы: ${p.boundaries || ''}`,
      `ЗАКРЕПЛЁННЫЕ ФАКТЫ И ПАМЯТЬ: ${facts || 'Пока нет.'}`,
      `КРАТКОЕ РЕЗЮМЕ СЮЖЕТА: ${chat.summary || 'История только начинается.'}`,
      history ? `НЕДАВНИЕ СОБЫТИЯ ДЛЯ НЕПРЕРЫВНОСТИ:\n${history}` : ''
    ];
    return parts.filter(Boolean).join('\n\n');
  }
  function buildUserPrompt(text, chat) {
    const facts = (chat.facts || []).length ? `\n\n[Память истории — учитывай ненавязчиво, не перечисляй: ${(chat.facts||[]).join('; ')}]` : '';
    const summary = chat.summary ? `\n[Текущее резюме: ${chat.summary}]` : '';
    return `${text}${facts}${summary}`;
  }
  function responseTokenBudget() {
    return db.settings.responseLength === 'short' ? 72 : (db.settings.responseLength === 'long' ? 240 : 128);
  }
  function sendCurrentMessage() {
    if (state.generating) return;
    const input = document.getElementById('message-input');
    const text = (input?.value || '').trim();
    if (!text) return;
    const chat = getChat(); if (!chat) return;
    chat.messages.push({id:id(),role:'user',text,time:now()}); chat.updatedAt = now();
    const placeholder = {id:id(),role:'assistant',text:'',time:now(),generating:true};
    const requestId = id();
    chat.messages.push(placeholder); state.generating = true; state.generationChatId = chat.id; state.generationMessageId = placeholder.id; state.generationRequestId = requestId; state.generationTimer = null; saveDB(); renderChat();
    if (!hasNativeModel()) {
      if (!sessionStorage.getItem('fallback-note-seen')) { toast('Сценарный режим работает офлайн, но ответы шаблонные. Добавь GGUF для локального ИИ.'); sessionStorage.setItem('fallback-note-seen','1'); }
      state.generationTimer = window.setTimeout(() => {
        if (state.generationRequestId !== requestId) return;
        const answer = offlineReply(chatChar(chat), text, chat);
        finishGeneration(placeholder.id, answer, chat.id, requestId);
      }, 420 + Math.min(900, text.length*7));
      return;
    }
    const ch = chatChar(chat);
    const prompt = createSystemPrompt(ch, chat, chat.messages.slice(0, -2));
    const req = {requestId,systemPrompt:prompt,userPrompt:buildUserPrompt(text,chat),sessionKey:chat.id,maxTokens:responseTokenBudget(),temperature:Number(db.settings.temperature)||0.78};
    try { Android.generate(JSON.stringify(req)); }
    catch (e) { finishGeneration(placeholder.id, offlineReply(ch,text,chat), chat.id, requestId); toast('Не удалось запустить модель. Переключилась на сценарный режим.'); }
  }
  function fallbackName(ch) { return (ch.name || 'Персонаж').split(' ')[0]; }
  function offlineReply(ch, text, chat) {
    const name = fallbackName(ch); const low = text.toLowerCase();
    const n = (chat.messages || []).filter(m=>m.role==='assistant').length;
    const action = [
      '*Он ненадолго задерживает взгляд на твоих словах, затем чуть расслабляет плечи.*',
      '*В комнате тихо потрескивает старый радиоприёмник. Он поворачивается к тебе, не торопя с ответом.*',
      '*Он осторожно ставит кружку на стол и оставляет между вами достаточно места.*',
      '*Несколько секунд он подбирает слова, перебирая пальцами край рукава.*',
      '*Он переводит взгляд на окно, будто даёт тишине устроиться рядом с вами обоими.*'
    ][n % 5];
    const first = (text.replace(/\s+/g,' ').trim().split(/[.!?…]/)[0] || '').slice(0,90);
    let line;
    if (/(страшно|боюсь|тревож|паник|небезопас|пугает)/i.test(low)) {
      line = `— Понимаю. Не нужно сейчас ничего доказывать. Давай просто останемся здесь и решим только то, что нужно в эту минуту. Хочешь, я помолчу рядом или помогу отвлечься?`;
    } else if (/(груст|плохо|устал|одинок|плак|больно|тяжело|обидно|разбит|не могу)/i.test(low)) {
      line = `— Мне жаль, что тебе так тяжело. *Он говорит тише, оставляя тебе время.* Я не стану заставлять тебя объяснять всё сразу. С чего тебе было бы легче начать — или хочешь просто посидеть рядом?`;
    } else if (/(люблю|скучаю|обними|рядом|поцел|не уходи|держи меня)/i.test(low)) {
      line = `— Я здесь, — отвечает он негромко. *Он не приближается без приглашения, но остаётся рядом.* Если тебе хочется, я могу обнять тебя. А если нет — просто побуду здесь.`;
    } else if (/[?？]$/.test(text.trim()) || /^(что|почему|как|зачем|когда|где|ты )/i.test(low)) {
      line = `— Не уверен, что знаю правильный ответ, — признаётся он после паузы. — Но могу подумать вместе с тобой. Что в этом для тебя сейчас самое важное?`;
    } else if (/(встретил|нашла|случил|пришёл|пришла|увидел|увидела|сказал|сказала)/i.test(low)) {
      line = `— Понял, — говорит он, не перебивая. — И что ты хочешь сделать дальше? Мы можем не спешить и посмотреть, куда эта история повернёт.`;
    } else {
      line = `— Я услышал тебя, — говорит ${name.toLowerCase()} после короткой паузы. — ${first ? `«${first}${first.length >= 89 ? '…' : ''}» — ` : ''}Расскажешь, что в этом для тебя важнее всего?`;
    }
    const personaStyle = ch.voice ? '' : '';
    return `${action}\n\n${line}${personaStyle}`;
  }
  function clearGenerationState(requestId) {
    if (!requestId || state.generationRequestId !== requestId) return false;
    if (state.generationTimer) clearTimeout(state.generationTimer);
    state.generationTimer = null;
    state.generating = false;
    state.generationChatId = null;
    state.generationMessageId = null;
    state.generationRequestId = null;
    return true;
  }
  function cancelActiveGeneration(chatId = state.generationChatId) {
    const requestId = state.generationRequestId;
    if (!state.generating || !requestId || !state.generationChatId || (chatId && state.generationChatId !== chatId)) return false;
    try { window.Android?.cancelGeneration?.(requestId); } catch (_) {}
    if (state.generationTimer) clearTimeout(state.generationTimer);
    const chat = db.chats.find(c => c.id === state.generationChatId);
    if (chat) {
      chat.messages = chat.messages.filter(m => m.id !== state.generationMessageId);
      chat.updatedAt = now();
    }
    clearGenerationState(requestId);
    if (chat) saveDB();
    return true;
  }
  function finishGeneration(messageId, text, chatId = state.generationChatId, requestId = state.generationRequestId) {
    if (!requestId || requestId !== state.generationRequestId) return;
    const chat = db.chats.find(c => c.id === chatId);
    if (!chat) { clearGenerationState(requestId); return; }
    const msg = chat.messages.find(m=>m.id===messageId);
    if (!msg) { clearGenerationState(requestId); return; }
    msg.text = (text || '').trim() || '*Он задумчиво молчит, подбирая слова. Попробуй повторить реплику.*';
    delete msg.generating; msg.time = now(); chat.updatedAt = now();
    clearGenerationState(requestId);
    saveDB();
    if (state.route === 'chat' && state.activeChatId === chat.id) renderChat();
  }
  function appendNativeChunk(requestId, chunk) {
    if (!requestId || requestId !== state.generationRequestId) return;
    const chat = db.chats.find(c => c.id === state.generationChatId); if (!chat) return;
    const msg = chat.messages.find(m => m.id === state.generationMessageId);
    if (!msg) return;
    msg.text = (msg.text || '') + String(chunk || '');
    if (state.route !== 'chat' || state.activeChatId !== chat.id) return;
    const bubble = document.querySelector(`[data-message-content="${msg.id}"]`);
    if (bubble) bubble.innerHTML = formatText(msg.text) || '<span class="generating-indicator"><i></i><i></i><i></i></span>';
    const list = document.getElementById('message-list'); if (list) list.scrollTop = list.scrollHeight;
  }
  function nativeDone(requestId) {
    if (!requestId || requestId !== state.generationRequestId) return;
    const chat = db.chats.find(c => c.id === state.generationChatId);
    const msg = chat?.messages.find(m => m.id === state.generationMessageId);
    if (msg) finishGeneration(msg.id, msg.text, chat.id, requestId);
    else clearGenerationState(requestId);
  }
  function nativeError(requestId, error) {
    if (!requestId || requestId !== state.generationRequestId) return;
    const chat = db.chats.find(c => c.id === state.generationChatId);
    const msg = chat?.messages.find(m => m.id === state.generationMessageId);
    if (!chat || !msg) { clearGenerationState(requestId); return; }
    const user = [...chat.messages].reverse().find(m=>m.role==='user');
    finishGeneration(msg.id, offlineReply(chatChar(chat), user?.text || '', chat), chat.id, requestId);
    toast(`Локальная модель не запустилась: ${String(error || 'ошибка')}. Сцена продолжена в простом режиме. Открой настройки модели, чтобы проверить или заменить файл.`, 9000);
  }
  window.onNativeChunk = appendNativeChunk;
  window.onNativeDone = nativeDone;
  window.onNativeError = nativeError;
  window.onModelImported = (name) => { state.modelInfo = null; refreshModelInfo(); render(); toast(`Модель добавлена: ${name}`); };
  window.onModelDownloadChanged = () => { state.modelInfo = null; if (state.modal?.type === 'model') updateModelModal(); };
  window.onBackupLoaded = (json) => importBackup(json);
  window.handleSystemBack = () => {
    if (state.modal) { closeModal(); return true; }
    if (state.route === 'chat') { go(['home','library','profile'].includes(state.returnRoute) ? state.returnRoute : 'home'); return true; }
    if (state.route === 'editor') {
      state.editorDraft = null; state.newCharacter = false; state.editingCharId = null;
      go(state.returnRoute === 'editor' ? 'library' : state.returnRoute || 'library'); return true;
    }
    if (state.route !== 'home') { go('home'); return true; }
    return false;
  };
  document.addEventListener('keydown', ev => { if (ev.key === 'Escape' && window.handleSystemBack()) ev.preventDefault(); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden && state.modal?.type === 'model') updateModelModal(); });

  function readDownloadProgress() {
    try { return window.Android?.getDownloadProgress ? JSON.parse(Android.getDownloadProgress()) : null; }
    catch (_) { return null; }
  }
  function stopModelProgressPolling() {
    if (state.progressTimer) { clearInterval(state.progressTimer); state.progressTimer = null; }
  }
  function startModelProgressPolling() {
    if (state.progressTimer) return;
    state.progressTimer = setInterval(() => {
      if (state.modal?.type !== 'model') { stopModelProgressPolling(); return; }
      if (!document.hidden) updateModelModal();
    }, 1500);
  }
  function updateModelModal() {
    if (state.modal?.type !== 'model') { stopModelProgressPolling(); return; }
    state.modelInfo = null;
    let model = refreshModelInfo();
    const download = readDownloadProgress() || {status:'idle'};
    if (download.status === 'complete' && !model.available) { state.modelInfo = null; model = refreshModelInfo(); }
    const status = download.status || 'idle';
    const active = ['running','pending','paused'].includes(status);
    const title = document.getElementById('model-title');
    const description = document.getElementById('model-description');
    const progressWrap = document.getElementById('model-progress');
    const progressFill = document.getElementById('model-progress-fill');
    const progressLabel = document.getElementById('model-progress-label');
    const message = document.getElementById('model-download-message');
    const actions = document.getElementById('model-actions');
    if (!title || !description || !progressWrap || !progressFill || !progressLabel || !message || !actions) return;
    title.textContent = model.available ? `Подключён файл: ${model.name || 'GGUF'}` : 'Qwen2.5 · 1.5B · Q4_K_M';
    description.textContent = model.available
      ? 'Файл уже сохранён в хранилище приложения. Он останется доступным в авиарежиме.'
      : '≈986 МБ. Нужны Wi‑Fi и не менее 1,1 ГБ свободного места. Для телефона 2020 года безопасный выбор; на 4 ГБ RAM может быть медленно или не хватить памяти, 6 ГБ+ предпочтительнее.';
    progressWrap.hidden = !active;
    const percent = Math.max(0, Math.min(100, Number(download.progress) || 0));
    progressFill.style.width = `${percent}%`;
    progressLabel.textContent = status === 'pending'
      ? `В очереди Android · ${download.total ? `${Math.round(percent)}% · ` : ''}ожидание запуска`
      : status === 'paused'
        ? `На паузе · ${Math.round(percent)}%${download.total ? ` · ${formatBytes(download.downloaded || 0)} / ${formatBytes(download.total)}` : ''}`
        : `Загрузка · ${Math.round(percent)}%${download.total ? ` · ${formatBytes(download.downloaded || 0)} / ${formatBytes(download.total)}` : ' · около 986 МБ'}`;

    let stalled = false;
    if (active) {
      const key = String(download.id ?? 'current');
      const bytes = Number(download.downloaded) || 0;
      if (!state.downloadWatch || state.downloadWatch.id !== key || bytes > state.downloadWatch.bytes) {
        state.downloadWatch = {id:key, bytes, changedAt:Date.now()};
      }
      stalled = status === 'running' && Date.now() - state.downloadWatch.changedAt >= 15000;
    } else state.downloadWatch = null;
    const note = status === 'paused' || status === 'pending' || status === 'failed'
      ? (download.reasonText || (status === 'paused' ? 'Android приостановил загрузку. Проверь Wi‑Fi и настройки загрузок.' : status === 'pending' ? 'Загрузка стоит в очереди Android; обычно она запускается через несколько секунд.' : 'Android не смог завершить загрузку. Проверь подключение и свободное место, затем попробуй снова.'))
      : (model.modelError || model.loadError) ? (model.modelError || model.loadError)
      : status === 'complete' && !model.available ? 'Android отметил загрузку завершённой, но файл модели не найден. Проверь уведомление «Загрузки» и место на телефоне; попробуй скачать заново.'
      : stalled ? 'Android сообщает, что загрузка активна, но данные не приходят уже 15 секунд. Проверь Wi‑Fi, свободное место и уведомление «Загрузки»; при лимитной сети Android может ждать немеренную Wi‑Fi.'
      : status === 'running' ? 'Можно закрыть это окно: Android продолжит загрузку в фоне.' : '';
    message.textContent = note;
    message.hidden = !note;
    const mode = active ? 'active' : model.available ? 'available' : status === 'failed' || model.modelError ? 'failed' : 'idle';
    if (actions.dataset.mode !== mode) {
      actions.dataset.mode = mode;
      actions.innerHTML = mode === 'active'
        ? `<button class="btn danger full" data-action="cancel-download">${svg('close',14)} Отменить загрузку</button><button class="btn ghost full" data-action="close-modal">Свернуть</button>`
        : mode === 'available'
          ? `<button class="btn full" data-action="test-model">${svg('play',14)} Перейти к истории</button><button class="btn secondary full" data-action="import-model">${svg('folder',15)} Заменить модель</button><button class="btn danger full" data-action="remove-model">${svg('trash',14)} Удалить файл модели</button>`
          : `<button class="btn full" data-action="download-model">${svg('download',15)} ${mode === 'failed' ? (model.modelError ? 'Скачать Qwen заново' : 'Попробовать снова') : 'Скачать Qwen2.5 · 986 МБ'}</button><button class="btn secondary full" data-action="import-model">${svg('folder',15)} Импортировать .gguf</button>${model.modelError ? `<button class="btn danger full" data-action="remove-model">${svg('trash',14)} Удалить повреждённый файл</button>` : ''}<button class="btn ghost full" data-action="close-modal">Позже</button>`;
    }
    if (active) startModelProgressPolling(); else stopModelProgressPolling();
  }
  function openModal(type, data = {}) { if (type !== 'model') stopModelProgressPolling(); state.modal = Object.assign({type}, data); renderModal(); }
  function closeModal() { state.modal = null; stopModelProgressPolling(); renderModal(); }
  function renderModal() {
    const root = document.getElementById('modal-root');
    if (!state.modal) { stopModelProgressPolling(); state.downloadWatch = null; root.innerHTML = ''; return; }
    const m = state.modal;
    if (m.type !== 'model') stopModelProgressPolling();
    let title = ''; let body = '';
    if (m.type === 'model-offer') {
      title = 'Подготовить офлайн-ИИ?';
      body = `<p class="modal-copy">При первом запуске можно сразу поставить локальную нейросеть. Она скачивается один раз по Wi‑Fi и затем работает без сети.</p><div class="model-card"><strong>Qwen2.5 · 1.5B · Q4_K_M</strong><p>Файл ≈986 МБ; нужно не менее 1,1 ГБ свободного места. На телефоне 2020 года с 6 ГБ RAM обычно будет комфортнее; на 4 ГБ может работать медленно или не хватить памяти. Контекст — до 4096 токенов; длинные истории могут потребовать больше памяти.</p></div><div class="modal-actions" style="flex-direction:column"><button class="btn full" data-action="install-model-first-run">${svg('download',15)} Скачать по Wi‑Fi</button><button class="btn secondary full" data-action="skip-model-offer">Продолжить без модели</button></div><p class="small-copy">Загрузка не начнётся без нажатия. Её можно отменить; позднее — запустить в настройках или импортировать другой GGUF.</p>`;
    } else if (m.type === 'model-download-confirm') {
      title = 'Скачать модель?';
      body = `<p class="modal-copy">На телефон загрузится Qwen2.5 1.5B Instruct в квантовании Q4_K_M.</p><div class="model-card"><strong>986 МБ · только Wi‑Fi</strong><p>Нужно не менее 1,1 ГБ свободного места. Загрузка не расходует мобильный трафик; после неё модель можно использовать офлайн.</p></div><div class="modal-actions"><button class="btn secondary" data-action="cancel-model-download">Отмена</button><button class="btn" data-action="confirm-model-download">${svg('download',14)} Скачать</button></div>`;
    } else if (m.type === 'model') {
      title = 'Локальный ИИ';
      body = `<p class="modal-copy">Переписки и персонажи хранятся на телефоне. Чтобы получать нейросетевые ответы без сети, один раз скачай модель или импортируй совместимый файл <b>.gguf</b>.</p>
        <div class="model-card"><strong id="model-title">Qwen2.5 · 1.5B · Q4_K_M</strong><p id="model-description">≈986 МБ. Нужны Wi‑Fi и не менее 1,1 ГБ свободного места.</p>
          <div class="model-progress" id="model-progress" hidden><div class="progress-track"><div class="progress-fill" id="model-progress-fill"></div></div><p class="progress-label" id="model-progress-label"></p></div>
          <p class="download-note" id="model-download-message" hidden></p>
        </div>
        <div class="modal-actions model-actions" id="model-actions" style="flex-direction:column"></div>
        <div class="divider"></div><p class="small-copy">Статус загрузки сообщает Android DownloadManager; загрузка может идти в фоне. Рекомендуемая Qwen2.5-1.5B-Instruct Q4_K_M весит около 986 МБ и загружается с Hugging Face только по запросу. Переписки не отправляются в сеть.</p>`;
    } else if (m.type === 'settings') {
      title = 'Настройки';
      body = `<p class="modal-copy">Настрой чтение и подготовь приложение к работе без сети.</p>
        <div class="form-section" style="margin:0 0 12px"><div class="setting-row"><span class="setting-icon">${svg('type',17)}</span><div class="setting-copy"><strong>Шрифт сообщений</strong><small>Сейчас: ${Number(db.settings.fontSize)||18}px</small></div></div><div class="slider-row"><span>Аа</span><input id="modal-font-slider" type="range" min="15" max="22" value="${Number(db.settings.fontSize)||18}"><span style="font-size:15px">Аа</span></div></div>
        <div class="form-section" style="margin-bottom:12px"><div class="setting-row"><span class="setting-icon">${svg('sliders',17)}</span><div class="setting-copy"><strong>Подробность локальных ответов</strong><small>Короткие ответы генерируются быстрее и расходуют меньше памяти.</small></div></div><div class="row" style="flex-wrap:wrap">${[['short','Коротко'],['medium','Средне'],['long','Подробно']].map(([v,l])=>`<button class="chip ${db.settings.responseLength===v?'accent':''}" data-action="set-length" data-value="${v}">${l}</button>`).join('')}</div></div>
        <div class="form-section" style="margin-bottom:12px"><div class="switch-row"><div class="switch-copy"><strong>Живой RP-стиль</strong><small>Больше естественных реакций и вариативного ритма во всех чатах. Веса модели не меняются.</small></div><label class="switch"><input id="rp-style-toggle" type="checkbox" aria-label="Живой RP-стиль" ${db.settings.roleplayStyle !== false ? 'checked' : ''}><span></span></label></div></div>
        <button class="setting-row" style="width:100%;text-align:left;background:none" data-action="model-settings"><span class="setting-icon">${svg('download',17)}</span><span class="setting-copy"><strong>Модель для офлайна</strong><small>${modelInfo().available?esc(modelInfo().name||'GGUF'):'Не добавлена'}</small></span>${svg('chevron',16)}</button>
        <button class="setting-row" style="width:100%;text-align:left;background:none" data-action="export-backup"><span class="setting-icon">${svg('cloud',17)}</span><span class="setting-copy"><strong>Резервная копия</strong><small>Экспортировать персонажей и переписки в JSON.</small></span>${svg('chevron',16)}</button>
        <button class="setting-row" style="width:100%;text-align:left;background:none" data-action="licenses"><span class="setting-icon">${svg('info',17)}</span><span class="setting-copy"><strong>О приложении и лицензиях</strong><small>Состав, локальная работа и сторонние компоненты.</small></span>${svg('chevron',16)}</button>
        <div class="offline-card"><div class="offline-icon">${svg('shield',16)}</div><div><strong>Личные данные остаются здесь</strong><p>Облака и аккаунта нет. Интернет используется только для загрузки файла модели по твоему запросу.</p></div></div>
        <div class="modal-actions"><button class="btn secondary full" data-action="close-modal">Готово</button></div>`;
    } else if (m.type === 'licenses') {
      title = 'О приложении и лицензиях';
      let notice = 'MIT License\\n\\nCopyright (c) 2023-2026 The ggml authors\\n\\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the Software), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:\\n\\nThe above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.\\n\\nTHE SOFTWARE IS PROVIDED AS IS, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.';
      try { if (window.Android?.getLicenseText) notice = Android.getLicenseText(); } catch (_) {}
      body = `<p class="modal-copy"><b>Тихий сюжет</b> — локальное приложение для ролевых историй. У него нет аккаунта, облачной синхронизации или удалённого API для чата. Рекомендуемая модель скачивается только после согласия пользователя; после этого она работает без сети.</p><p class="small-copy">Нативный движок llama.cpp распространяется по MIT License. Полный текст уведомления ниже. Qwen2.5-1.5B GGUF не включена в APK; пользователь может загрузить её отдельно. Проверь лицензию модели и условия источника перед распространением.</p><pre style="white-space:pre-wrap;overflow-wrap:anywhere;padding:12px;border-radius:13px;background:rgba(0,0,0,.22);border:1px solid var(--line);color:#bdb8c5;font-size:9px;line-height:1.5">${esc(notice)}</pre><div class="modal-actions"><button class="btn full" data-action="close-modal">Закрыть</button></div>`;
    } else if (m.type === 'memory') {
      const chat = getChat(); title = 'Память и сюжет';
      if (!chat) { closeModal(); return; }
      body = `<p class="modal-copy">Эти заметки попадут в подсказку локальной модели и помогут сохранить важные детали. Записывай факты коротко: что произошло, что обещано, что персонаж не должен забыть.</p>
        <div class="field"><label>Краткое резюме сцены</label><textarea id="memory-summary" class="tall" placeholder="Где вы, что уже произошло и куда движется история…">${esc(chat.summary||'')}</textarea></div>
        <div class="section-head" style="margin-top:17px"><h2>Закреплённые факты</h2><span class="badge">${chat.facts?.length||0}</span></div>
        <div class="memory-list">${(chat.facts||[]).length ? chat.facts.map((f,i)=>`<div class="memory-item"><span>${svg('bookmark',13)}</span><span class="flex1">${esc(f)}</span><button class="tiny-btn" data-action="remove-fact" data-index="${i}" aria-label="Удалить">${svg('close',14)}</button></div>`).join('') : `<p class="small-copy">Пока нет закреплённых деталей. Их можно добавлять и прямо из меню сообщения.</p>`}</div>
        <div class="row"><input id="new-fact" class="field-input" style="flex:1;min-width:0;border:1px solid rgba(255,255,255,.09);border-radius:12px;padding:11px;background:rgba(8,9,14,.62);font-size:11px;outline:none" placeholder="Добавить важный факт…"><button class="btn small" data-action="add-fact">${svg('plus',14)} Добавить</button></div>
        <div class="modal-actions"><button class="btn full" data-action="save-memory">Сохранить память</button></div>`;
    } else if (m.type === 'character-menu') {
      const ch = getChar(m.charId); title = ch?.name || 'Персонаж';
      body = `<p class="modal-copy">${esc(ch?.tagline||'Настрой карточку или начни новую историю.')}</p><div class="modal-actions" style="flex-direction:column"><button class="btn full" data-action="start-chat" data-char="${esc(ch?.id)}">${svg('play',14)} Начать новую историю</button><button class="btn secondary full" data-action="edit-character" data-char="${esc(ch?.id)}">${svg('edit',14)} Редактировать карточку</button><button class="btn secondary full" data-action="duplicate-character" data-char="${esc(ch?.id)}">${svg('copy',14)} Создать копию</button><button class="btn danger full" data-action="confirm-delete-character" data-char="${esc(ch?.id)}">${svg('trash',14)} Удалить персонажа</button></div>`;
    } else if (m.type === 'confirm-delete-character') {
      title = 'Удалить персонажа?'; body = `<p class="modal-copy">Персонаж и его истории будут удалены с этого устройства. Это действие нельзя отменить. Если хочешь сохранить переписки — сначала экспортируй копию.</p><div class="modal-actions"><button class="btn secondary" data-action="close-modal">Оставить</button><button class="btn danger" data-action="delete-character" data-char="${esc(m.charId)}">Удалить</button></div>`;
    } else if (m.type === 'chat-menu') {
      const chat=getChat(); const ch=chatChar(chat); title='Сцена';
      body = `<div class="modal-actions" style="flex-direction:column;margin-top:0"><button class="btn secondary full" data-action="open-memory">${svg('memory',15)} Память и сюжет</button><button class="btn secondary full" data-action="edit-character" data-char="${esc(ch.id)}">${svg('edit',14)} Настроить персонажа</button><button class="btn secondary full" data-action="rename-chat">${svg('type',14)} Переименовать историю</button><button class="btn secondary full" data-action="export-backup">${svg('cloud',15)} Экспортировать резервную копию</button><button class="btn danger full" data-action="delete-chat">${svg('trash',14)} Удалить эту историю</button></div>`;
    } else if (m.type === 'message-menu') {
      const chat=getChat(), msg=chat?.messages.find(x=>x.id===m.messageId); title=msg?.role==='user'?'Твоя реплика':'Ответ персонажа';
      body=`<p class="modal-copy">${esc((msg?.text||'').slice(0,160))}${(msg?.text||'').length>160?'…':''}</p><div class="modal-actions" style="flex-direction:column;margin-top:0"><button class="btn secondary full" data-action="copy-message" data-message="${esc(m.messageId)}">${svg('copy',14)} Скопировать</button><button class="btn secondary full" data-action="pin-message" data-message="${esc(m.messageId)}">${svg('bookmark',14)} Закрепить в памяти</button>${msg?.role==='user'?`<button class="btn secondary full" data-action="edit-message" data-message="${esc(m.messageId)}">${svg('edit',14)} Исправить и продолжить</button>`:`<button class="btn secondary full" data-action="regenerate" data-message="${esc(m.messageId)}">${svg('refresh',14)} Новый вариант ответа</button>`}<button class="btn danger full" data-action="delete-message" data-message="${esc(m.messageId)}">${svg('trash',14)} Удалить реплику</button></div>`;
    } else if (m.type === 'edit-message') {
      const chat=getChat(), msg=chat?.messages.find(x=>x.id===m.messageId); title='Исправить реплику';
      body=`<div class="field"><label>Текст</label><textarea id="edited-message" class="tall">${esc(msg?.text||'')}</textarea></div><p class="small-copy">Все последующие ответы будут удалены, после чего персонаж ответит заново.</p><div class="modal-actions"><button class="btn secondary" data-action="close-modal">Отмена</button><button class="btn" data-action="save-edited-message" data-message="${esc(m.messageId)}">${svg('refresh',13)} Исправить и продолжить</button></div>`;
    } else if (m.type === 'persona-edit') {
      title='Моя персона';
      body=`<div class="field"><label>Имя</label><input id="persona-name" value="${esc(db.persona.name||'')}" placeholder="Даша"></div><div class="field"><label>Местоимения</label><input id="persona-pronouns" value="${esc(db.persona.pronouns||'')}" placeholder="она / её"></div><div class="field"><label>О себе и роли в историях</label><textarea id="persona-about" class="tall" placeholder="Внешность, характер, важные детали, которые герои могут знать…">${esc(db.persona.about||'')}</textarea></div><div class="field"><label>Границы и предпочтения</label><textarea id="persona-boundaries" placeholder="Что герои не должны делать или предполагать?">${esc(db.persona.boundaries||'')}</textarea></div><div class="modal-actions"><button class="btn secondary" data-action="close-modal">Отмена</button><button class="btn" data-action="save-persona">Сохранить</button></div>`;
    } else if (m.type === 'rename-chat') {
      const chat=getChat(); title='Название истории'; body=`<div class="field"><label>Как ты назовёшь эту историю?</label><input id="chat-name" value="${esc(chat?.title||'')}" maxlength="80"></div><div class="modal-actions"><button class="btn secondary" data-action="close-modal">Отмена</button><button class="btn" data-action="save-chat-name">Сохранить</button></div>`;
    } else if (m.type === 'confirm-delete-chat') {
      title='Удалить историю?'; body=`<p class="modal-copy">Переписка и заметки к ней будут удалены. Карточка персонажа останется.</p><div class="modal-actions"><button class="btn secondary" data-action="close-modal">Отмена</button><button class="btn danger" data-action="confirm-delete-chat">Удалить</button></div>`;
    } else if (m.type === 'editor-help') {
      title='Подсказка для сильной карточки'; body=`<p class="modal-copy">Лучше всего работают конкретные поведенческие детали: что персонаж замечает, как проявляет заботу, как говорит, что делает, когда тревожится. В поле «Сюжет» запиши отдельные события и правила мира, а в «Сцене» — только то, что происходит сейчас. Вступление должно закончиться местом, где пользователь может выбрать ход.</p><div class="modal-actions"><button class="btn full" data-action="close-modal">Понятно</button></div>`;
    }
    root.innerHTML = `<div class="modal-backdrop" data-action="backdrop-close"><section class="modal" role="dialog" aria-modal="true"><header class="modal-head"><h2>${esc(title)}</h2><button class="icon-btn" data-action="close-modal" aria-label="Закрыть">${svg('close',16)}</button></header><div class="modal-body">${body}</div></section></div>`;
    if (m.type === 'model') updateModelModal();
    if (m.type === 'settings') {
      const slider = document.getElementById('modal-font-slider');
      slider?.addEventListener('input', () => { db.settings.fontSize=Number(slider.value); saveDB(); const label=document.querySelector('.setting-copy small'); if(label) label.textContent=`Сейчас: ${slider.value}px`; document.documentElement.style.setProperty('--font-chat',`${slider.value}px`); });
    }
  }
  function toast(text, duration = 3200) {
    document.querySelector('.toast')?.remove();
    const el=document.createElement('div'); el.className='toast'; el.textContent=text; document.body.appendChild(el);
    clearTimeout(state.toastTimer); state.toastTimer=setTimeout(()=>el.remove(),duration);
  }
  function syncRoleplayStyleUI() {
    const enabled = db.settings.roleplayStyle !== false;
    document.querySelectorAll('[data-action="toggle-rp-style"]').forEach(button => {
      button.classList.toggle('accent', enabled);
      button.setAttribute('aria-pressed', String(enabled));
      button.innerHTML = `<i class="chip-dot" style="background:${enabled?'#cbb8ff':'#777581'}"></i>RP-стиль ${enabled?'вкл':'выкл'}`;
    });
    document.querySelectorAll('[id="rp-style-toggle"]').forEach(toggle => { toggle.checked = enabled; });
    const toggle = document.getElementById('rp-style-toggle');
    if (toggle) toggle.checked = enabled;
  }
  function formatBytes(n) { if(!n) return ''; if(n<1000000) return `${Math.round(n/1000)} КБ`; return `${(n/1000000).toFixed(n<10000000?1:0)} МБ`; }
  function savePersona() {
    db.persona.name=document.getElementById('persona-name')?.value.trim()||'Даша';
    db.persona.pronouns=document.getElementById('persona-pronouns')?.value.trim()||'';
    db.persona.about=document.getElementById('persona-about')?.value.trim()||'';
    db.persona.boundaries=document.getElementById('persona-boundaries')?.value.trim()||'';
    saveDB(); closeModal(); render(); toast('Персона обновлена.');
  }
  function regenerate(messageId) {
    if (state.generating) return;
    const chat=getChat(); if(!chat) return;
    const idx=chat.messages.findIndex(m=>m.id===messageId);
    if(idx<0) return;
    let userIdx = chat.messages[idx].role==='user' ? idx : idx-1;
    while(userIdx>=0 && chat.messages[userIdx].role!=='user') userIdx--;
    if(userIdx<0) { toast('Для новой версии нужен ход пользователя.'); closeModal(); return; }
    const userMsg=chat.messages[userIdx]; const previous=chat.messages.slice(0,userIdx);
    chat.messages=chat.messages.slice(0,userIdx+1);
    const placeholder={id:id(),role:'assistant',text:'',time:now(),generating:true}; chat.messages.push(placeholder);
    const requestId=id();
    chat.updatedAt=now(); state.generating=true; state.generationChatId=chat.id; state.generationMessageId=placeholder.id; state.generationRequestId=requestId; state.generationTimer=null; closeModal(); saveDB(); renderChat();
    const ch=chatChar(chat);
    if(!hasNativeModel()) { state.generationTimer=window.setTimeout(()=>{if(state.generationRequestId===requestId)finishGeneration(placeholder.id,offlineReply(ch,userMsg.text,chat),chat.id,requestId);},450); return; }
    const req={requestId,systemPrompt:createSystemPrompt(ch,chat,previous),userPrompt:buildUserPrompt(userMsg.text,chat),sessionKey:`${chat.id}:branch:${Date.now()}`,maxTokens:responseTokenBudget(),temperature:Number(db.settings.temperature)||0.78};
    try{Android.generate(JSON.stringify(req));}catch(e){finishGeneration(placeholder.id,offlineReply(ch,userMsg.text,chat),chat.id,requestId);}
  }
  function exportBackup() {
    const json=JSON.stringify({format:'tihiy-syuzhet-backup',version:1,exportedAt:now(),data:db},null,2);
    try { if(window.Android?.exportBackup) { Android.exportBackup(json); toast('Подготовь место для JSON-файла в системном окне.'); }
      else { const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([json],{type:'application/json'})); a.download='tihiy-syuzhet-backup.json'; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href),1000); } }
    catch(e){ toast('Не удалось открыть экспорт.'); }
  }
  function importBackup(json) {
    try {
      const parsed=JSON.parse(json); const imported=parsed.data || parsed;
      if(!Array.isArray(imported.characters)||!Array.isArray(imported.chats)||!imported.persona) throw new Error('Неподходящий файл');
      db=Object.assign(freshSeed(),imported,{settings:Object.assign({},SEED.settings,imported.settings||{})}); removeRetiredSeedCharacters(db); saveDB(); state.modal=null; state.activeChatId=null; state.route='home'; render(); toast('Резервная копия восстановлена.');
    } catch(e) { toast('Не получилось прочитать эту копию.'); }
  }
  function chooseAvatar() { state.avatarTarget=state.newCharacter ? 'draft' : state.editingCharId; document.getElementById('avatar-file')?.click(); }
  async function handleAvatarFile(file) {
    if(!file) return;
    try {
      const dataUrl=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file);});
      const img=new Image(); img.src=dataUrl; await img.decode();
      const canvas=document.createElement('canvas'); const side=512; canvas.width=side; canvas.height=side;
      const ctx=canvas.getContext('2d'); const scale=Math.max(side/img.width,side/img.height); const w=img.width*scale,h=img.height*scale; ctx.drawImage(img,(side-w)/2,(side-h)/2,w,h);
      const compressed=canvas.toDataURL('image/jpeg',0.84);
      if(state.avatarTarget==='draft'&&state.editorDraft) state.editorDraft.avatar=compressed;
      else { const c=getChar(state.avatarTarget); if(c){c.avatar=compressed;saveDB();} }
      render(); toast('Аватар обновлён.');
    } catch(e) { toast('Не удалось открыть это изображение.'); }
  }
  function bindGlobalEvents() {
    document.addEventListener('click', (ev) => {
      const node=ev.target.closest('[data-action]'); if(!node) return;
      const action=node.dataset.action;
      if(action==='backdrop-close' && ev.target===node){ closeModal(); return; }
      if(action==='close-modal'){closeModal();return;}
      if(action==='goto-home'){state.search='';go('home');return;}
      if(action==='goto-library'){go('library');return;}
      if(action==='goto-profile'){go('profile');return;}
      if(action==='settings'){openModal('settings');return;}
      if(action==='model-settings'){openModal('model');return;}
      if(action==='licenses'){openModal('licenses');return;}
      if(action==='new-character'){openEditor();return;}
      if(action==='start-chat'){ev.stopPropagation();makeChat(node.dataset.char || db.characters[0]?.id);return;}
      if(action==='open-chat'){openChat(node.dataset.chat);return;}
      if(action==='edit-character'){const cid=node.dataset.char || state.modal?.charId;closeModal();openEditor(cid);return;}
      if(action==='character-menu'){openModal('character-menu',{charId:node.dataset.char});return;}
      if(action==='duplicate-character'){const original=getChar(node.dataset.char);if(original){const copy=JSON.parse(JSON.stringify(original));copy.id=id();copy.name=`${original.name} — копия`;copy.createdAt=now();db.characters.unshift(copy);saveDB();closeModal();render();toast('Копия создана.');}return;}
      if(action==='confirm-delete-character'){openModal('confirm-delete-character',{charId:node.dataset.char});return;}
      if(action==='delete-character'){const cid=node.dataset.char;const activeChat=db.chats.find(c=>c.id===state.generationChatId);if(activeChat?.characterId===cid)cancelActiveGeneration(activeChat.id);db.characters=db.characters.filter(c=>c.id!==cid);db.chats=db.chats.filter(c=>c.characterId!==cid);saveDB();closeModal();go('library');toast('Персонаж удалён.');return;}
      if(action==='cancel-editor'){state.editorDraft=null;state.newCharacter=false;state.editingCharId=null;go(state.returnRoute==='editor'?'library':state.returnRoute||'library');return;}
      if(action==='pick-avatar'){chooseAvatar();return;}
      if(action==='save-character'){saveCharacter(false);return;}
      if(action==='save-and-start'){saveCharacter(true);return;}
      if(action==='editor-help'){openModal('editor-help');return;}
      if(action==='persona-edit'){openModal('persona-edit');return;}
      if(action==='save-persona'){savePersona();return;}
      if(action==='back-from-chat'){go(['home','library','profile'].includes(state.returnRoute)?state.returnRoute:'home');return;}
      if(action==='open-memory'){openModal('memory');return;}
      if(action==='chat-menu'){openModal('chat-menu');return;}
      if(action==='message-menu'){openModal('message-menu',{messageId:node.dataset.message});return;}
      if(action==='copy-message'){const msg=getChat()?.messages.find(x=>x.id===node.dataset.message);if(msg){if(window.Android?.copyText)Android.copyText(msg.text);else navigator.clipboard?.writeText(msg.text);toast('Реплика скопирована.');}closeModal();return;}
      if(action==='pin-message'){const chat=getChat(),msg=chat?.messages.find(x=>x.id===node.dataset.message);if(msg){if(!chat.facts)chat.facts=[];const fact=msg.text.slice(0,320);if(!chat.facts.includes(fact))chat.facts.push(fact);msg.pinned=true;saveDB();closeModal();renderChat();toast('Добавлено в память истории.');}return;}
      if(action==='edit-message'){const messageId=node.dataset.message;openModal('edit-message',{messageId});return;}
      if(action==='save-edited-message'){const chat=getChat(),idx=chat?.messages.findIndex(x=>x.id===node.dataset.message),text=document.getElementById('edited-message')?.value.trim();if(idx>=0&&text){chat.messages[idx].text=text;const u=chat.messages[idx].role==='user'?idx:idx-1;chat.messages=chat.messages.slice(0,Math.max(0,u+1));const user=chat.messages[chat.messages.length-1];closeModal();saveDB();if(user?.role==='user')regenerate(user.id);else renderChat();}return;}
      if(action==='regenerate'){regenerate(node.dataset.message);return;}
      if(action==='delete-message'){const chat=getChat();if(chat){if(state.generationChatId===chat.id&&state.generationMessageId===node.dataset.message)cancelActiveGeneration(chat.id);const idx=chat.messages.findIndex(x=>x.id===node.dataset.message);if(idx>=0)chat.messages.splice(idx,1);saveDB();closeModal();renderChat();}return;}
      if(action==='save-memory'){const chat=getChat();if(chat){chat.summary=document.getElementById('memory-summary')?.value.trim()||'';chat.updatedAt=now();saveDB();closeModal();renderChat();toast('Память сцены сохранена.');}return;}
      if(action==='add-fact'){const input=document.getElementById('new-fact'),text=input?.value.trim(),chat=getChat();if(text&&chat){chat.facts=chat.facts||[];chat.facts.push(text.slice(0,300));saveDB();openModal('memory');}return;}
      if(action==='remove-fact'){const chat=getChat();if(chat){chat.facts.splice(Number(node.dataset.index),1);saveDB();openModal('memory');}return;}
      if(action==='rename-chat'){closeModal();openModal('rename-chat');return;}
      if(action==='save-chat-name'){const chat=getChat();if(chat){chat.title=document.getElementById('chat-name')?.value.trim()||chatChar(chat).name;chat.updatedAt=now();saveDB();closeModal();renderChat();}return;}
      if(action==='delete-chat'){openModal('confirm-delete-chat');return;}
      if(action==='confirm-delete-chat'){const chatId=state.activeChatId;if(state.generationChatId===chatId)cancelActiveGeneration(chatId);db.chats=db.chats.filter(c=>c.id!==chatId);saveDB();closeModal();state.activeChatId=null;go('home');toast('История удалена.');return;}
      if(action==='export-backup'){closeModal();exportBackup();return;}
      if(action==='import-backup'){closeModal();if(window.Android?.importBackup)Android.importBackup();else{const inp=document.createElement('input');inp.type='file';inp.accept='application/json,.json';inp.onchange=()=>{const f=inp.files[0];if(f){const r=new FileReader();r.onload=()=>importBackup(r.result);r.readAsText(f);}};inp.click();}return;}
      if(action==='install-model-first-run'){if(!window.Android?.downloadDefaultModel){closeModal();toast('Загрузка доступна только в установленном APK.');return;}closeModal();try{Android.downloadDefaultModel();state.modelInfo=null;openModal('model');}catch(e){toast('Не получилось начать загрузку.');}return;}
      if(action==='skip-model-offer'){try{localStorage.setItem(MODEL_OFFER_KEY,'dismissed');}catch(_){}closeModal();return;}
      if(action==='download-model'){openModal('model-download-confirm');return;}
      if(action==='cancel-model-download'){openModal('model');return;}
      if(action==='confirm-model-download'){if(!window.Android?.downloadDefaultModel){closeModal();toast('Загрузка модели доступна только в установленном APK.');return;}closeModal();try{Android.downloadDefaultModel();state.modelInfo=null;openModal('model');}catch(e){toast('Не получилось начать загрузку.');}return;}
      if(action==='import-model'){if(window.Android?.openModelPicker)Android.openModelPicker();else toast('Импорт GGUF доступен в установленном APK.');return;}
      if(action==='model-progress'){state.modelInfo=null;updateModelModal();return;}
      if(action==='cancel-download'){if(window.Android?.cancelDownload)Android.cancelDownload();state.modelInfo=null;state.downloadWatch=null;updateModelModal();toast('Загрузка отменена.');return;}
      if(action==='remove-model'){if(confirm('Удалить файл модели с телефона? Истории и персонажи останутся.')){Android.removeModel();state.modelInfo=null;closeModal();render();toast('Файл модели удалён.');}return;}
      if(action==='test-model'){closeModal();if(state.activeChatId)go('chat');else makeChat(db.characters[0].id);return;}
      if(action==='toggle-rp-style'){
        db.settings.roleplayStyle = db.settings.roleplayStyle === false;
        saveDB();
        const enabled = db.settings.roleplayStyle;
        syncRoleplayStyleUI();
        toast(enabled ? 'Живой RP-стиль включён для всех чатов.' : 'Живой RP-стиль выключен; ответы будут проще.');
        return;
      }
      if(action==='set-length'){db.settings.responseLength=node.dataset.value;saveDB();render();if(state.modal)openModal('settings');toast('Длина ответа обновлена.');return;}
    });
    document.addEventListener('input', (ev) => {
      if(ev.target.id==='character-search'){state.search=ev.target.value;const pos=ev.target.selectionStart;renderLibrary();const next=document.getElementById('character-search');next?.focus();next?.setSelectionRange(pos,pos);}
      if(ev.target.id==='font-size-slider'){db.settings.fontSize=Number(ev.target.value);saveDB();const label=document.getElementById('font-value');if(label)label.textContent=`${ev.target.value}px`;document.documentElement.style.setProperty('--font-chat',`${ev.target.value}px`);}
    });
    document.addEventListener('change', (ev) => {
      if(ev.target.id==='avatar-file' && ev.target.files?.[0]) handleAvatarFile(ev.target.files[0]);
      if(ev.target.id==='rp-style-toggle') {
        db.settings.roleplayStyle = ev.target.checked;
        saveDB(); syncRoleplayStyleUI();
        toast(ev.target.checked ? 'Живой RP-стиль включён для всех чатов.' : 'Живой RP-стиль выключен; ответы будут проще.');
      }
    });
    document.addEventListener('input', (ev) => { if(ev.target.id==='font-size-slider'){db.settings.fontSize=Number(ev.target.value);saveDB();const label=document.getElementById('font-value');if(label)label.textContent=`${ev.target.value}px`;} });
  }
  function offerRecommendedModelOnce() {
    try {
      if (!window.Android?.getModelInfo || localStorage.getItem(MODEL_OFFER_KEY)) return;
      const info = refreshModelInfo();
      if (info.available || info.downloading) return;
      localStorage.setItem(MODEL_OFFER_KEY, 'shown');
      setTimeout(() => { if (!state.modal && !document.hidden) openModal('model-offer'); }, 650);
    } catch (_) {}
  }
  function init() {
    bindGlobalEvents();
    refreshModelInfo();
    render();
    offerRecommendedModelOnce();
    document.addEventListener('visibilitychange',()=>{if(!document.hidden){state.modelInfo=null;}});
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
