package ru.tihiy.syuzhet

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.OpenableColumns
import android.view.View
import android.view.WindowManager
import android.window.OnBackInvokedCallback
import android.window.OnBackInvokedDispatcher
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val inferenceMutex = Mutex()
    @Volatile private var engine: InferenceEngine? = null
    private var activeSessionKey: String? = null
    private var activeModelPath: String? = null
    private val generationJobs = ConcurrentHashMap<String, Job>()
    private val cancelledGenerationIds = ConcurrentHashMap.newKeySet<String>()
    @Volatile private var activeGenerationRequestId: String? = null
    private var avatarCallback: ValueCallback<Array<Uri>>? = null
    private var pendingBackupExport: String? = null
    private var safeTopInsetPx: Int = 0
    private var safeBottomInsetPx: Int = 0
    private var imeBottomInsetPx: Int = 0
    private var backPressPending: Boolean = false
    private var systemBackCallback: OnBackInvokedCallback? = null
    private val prefs by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    private val downloadManager by lazy { getSystemService(DOWNLOAD_SERVICE) as DownloadManager }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            val callback = OnBackInvokedCallback { dispatchSystemBack() }
            onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, callback)
            systemBackCallback = callback
        }
        window.statusBarColor = android.graphics.Color.rgb(9, 10, 15)
        window.navigationBarColor = android.graphics.Color.rgb(9, 10, 15)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightNavigationBars = false

        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.rgb(9, 10, 15))
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        webView.isVerticalScrollBarEnabled = false
        webView.isHorizontalScrollBarEnabled = false
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
            javaScriptCanOpenWindowsAutomatically = false
            setGeolocationEnabled(false)
            if (android.os.Build.VERSION.SDK_INT >= 16) {
                allowFileAccessFromFileURLs = false
                allowUniversalAccessFromFileURLs = false
            }
        }
        ViewCompat.setOnApplyWindowInsetsListener(webView) { _, insets ->
            val safeInsets = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val imeType = WindowInsetsCompat.Type.ime()
            safeTopInsetPx = safeInsets.top
            safeBottomInsetPx = safeInsets.bottom
            imeBottomInsetPx = if (insets.isVisible(imeType)) insets.getInsets(imeType).bottom else 0
            applySafeAreaInsets()
            insets
        }
        webView.addJavascriptInterface(WebBridge(), "Android")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val scheme = request?.url?.scheme ?: return true
                // The UI is fully local. Block navigation out of the packaged app assets.
                return scheme != "file" && scheme != "about"
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                applySafeAreaInsets()
                view?.let { ViewCompat.requestApplyInsets(it) }
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                avatarCallback?.onReceiveValue(null)
                avatarCallback = filePathCallback
                return try {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "image/*"
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivityForResult(intent, REQ_AVATAR)
                    true
                } catch (_: Exception) {
                    avatarCallback?.onReceiveValue(null)
                    avatarCallback = null
                    false
                }
            }
        }
        setContentView(webView)
        if (WebView.getCurrentWebViewPackage() != null) {
            val isDebuggable = applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE != 0
            WebView.setWebContentsDebuggingEnabled(isDebuggable)
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun applySafeAreaInsets() {
        if (!::webView.isInitialized) return
        val density = resources.displayMetrics.density.coerceAtLeast(1f)
        val top = String.format(Locale.US, "%.2f", safeTopInsetPx / density)
        val bottom = String.format(Locale.US, "%.2f", safeBottomInsetPx / density)
        val imeBottom = String.format(Locale.US, "%.2f", imeBottomInsetPx / density)
        webView.evaluateJavascript(
            "(function(){var r=document.documentElement;r.style.setProperty('--safe-top','${top}px');r.style.setProperty('--safe-bottom','${bottom}px');r.style.setProperty('--native-ime-bottom','${imeBottom}px');window.dispatchEvent(new Event('native-ime-insets'));})();",
            null
        )
    }

    private inner class WebBridge {
        @JavascriptInterface
        fun getModelInfo(): String = modelInfoJson()

        @JavascriptInterface
        fun getDownloadProgress(): String = downloadProgressJson()

        @JavascriptInterface
        fun downloadDefaultModel() {
            runOnUiThread { startModelDownload() }
        }

        @JavascriptInterface
        fun openModelPicker() {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivityForResult(intent, REQ_MODEL)
                } catch (_: Exception) {
                    showToast("Не удалось открыть выбор файла.")
                }
            }
        }

        @JavascriptInterface
        fun cancelDownload() {
            runOnUiThread { cancelModelDownload() }
        }

        @JavascriptInterface
        fun cancelGeneration(requestId: String) {
            cancelledGenerationIds.add(requestId)
            if (activeGenerationRequestId == requestId) engine?.cancelGeneration()
            generationJobs[requestId]?.cancel()
        }

        @JavascriptInterface
        fun removeModel() {
            scope.launch(Dispatchers.IO) {
                try {
                    inferenceMutex.withLock {
                        val current = engine
                        if (current?.state?.value is InferenceEngine.State.ModelReady) {
                            current.cleanUp()
                        }
                        activeSessionKey = null
                        activeModelPath = null
                        prefs.getString(KEY_MODEL_PATH, null)?.let { File(it).delete() }
                        downloadFile().delete()
                        prefs.edit().remove(KEY_MODEL_PATH).remove(KEY_DOWNLOAD_ERROR).remove(KEY_DOWNLOAD_ID).remove(KEY_MODEL_LOAD_ERROR).apply()
                    }
                    runOnUiThread { jsCall("onModelDownloadChanged", "") }
                } catch (_: Exception) {
                    runOnUiThread { showToast("Не удалось удалить модель сейчас.") }
                }
            }
        }

        @JavascriptInterface
        fun generate(requestJson: String) {
            val request = try { JSONObject(requestJson) } catch (_: Exception) {
                runOnUiThread { jsCall("onNativeError", "", "Некорректный запрос") }
                return
            }
            val requestId = request.optString("requestId").ifBlank { UUID.randomUUID().toString() }
            val systemPrompt = request.optString("systemPrompt")
            val userPrompt = request.optString("userPrompt")
            val sessionKey = request.optString("sessionKey", "default")
            val maxTokens = request.optInt("maxTokens", 128).coerceIn(64, 700)
            if (systemPrompt.isBlank() || userPrompt.isBlank()) {
                runOnUiThread { jsCall("onNativeError", requestId, "Пустой запрос") }
                return
            }

            val generationJob = scope.launch(Dispatchers.IO, start = CoroutineStart.LAZY) {
                inferenceMutex.withLock {
                    if (cancelledGenerationIds.contains(requestId)) return@withLock
                    activeGenerationRequestId = requestId
                    try {
                        val model = selectedModelFile()
                            ?: run { downloadProgressJson(); selectedModelFile() }
                            ?: throw IOException("Сначала добавь GGUF-модель в настройках")
                        val runtime = engine ?: AiChat.getInferenceEngine(applicationContext).also { engine = it }
                        val initialized = runtime.state.first {
                            it is InferenceEngine.State.Initialized || it is InferenceEngine.State.ModelReady || it is InferenceEngine.State.Error
                        }
                        if (initialized is InferenceEngine.State.Error) {
                            throw initialized.exception
                        }

                        val modelChanged = activeModelPath != null && activeModelPath != model.absolutePath
                        if (activeSessionKey != sessionKey || modelChanged || runtime.state.value !is InferenceEngine.State.ModelReady) {
                            if (runtime.state.value is InferenceEngine.State.Error) runtime.cleanUp()
                            if (modelChanged && runtime.state.value is InferenceEngine.State.ModelReady) runtime.cleanUp()
                            if (runtime.state.value !is InferenceEngine.State.ModelReady) {
                                runtime.loadModel(model.absolutePath)
                            }
                            runtime.setSystemPrompt(systemPrompt)
                            activeModelPath = model.absolutePath
                            prefs.edit().remove(KEY_MODEL_LOAD_ERROR).apply()
                            activeSessionKey = sessionKey
                        }

                        runtime.sendUserPrompt(userPrompt, maxTokens).collect { piece ->
                            if (piece.isNotEmpty()) runOnUiThread { jsCall("onNativeChunk", requestId, piece) }
                        }
                        runOnUiThread { jsCall("onNativeDone", requestId) }
                    } catch (_: CancellationException) {
                        engine?.cancelGeneration()
                    } catch (error: Throwable) {
                        val failedRuntime = engine
                        val failureState = failedRuntime?.state?.value as? InferenceEngine.State.Error
                        if (failureState != null) {
                            val detail = failureState.exception.message ?: failureState.exception.javaClass.simpleName
                            prefs.edit().putString(KEY_MODEL_LOAD_ERROR, detail.take(500)).apply()
                            try { failedRuntime.cleanUp() } catch (_: Exception) { }
                            activeSessionKey = null
                            activeModelPath = null
                        }
                        val message = (error.message ?: error.javaClass.simpleName).take(700)
                        runOnUiThread { jsCall("onNativeError", requestId, message) }
                    } finally {
                        if (activeGenerationRequestId == requestId) activeGenerationRequestId = null
                    }
                }
            }
            generationJobs[requestId] = generationJob
            generationJob.invokeOnCompletion {
                generationJobs.remove(requestId, generationJob)
                cancelledGenerationIds.remove(requestId)
            }
            generationJob.start()
        }

        @JavascriptInterface
        fun exportBackup(json: String) {
            runOnUiThread {
                pendingBackupExport = json
                try {
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/json"
                        putExtra(Intent.EXTRA_TITLE, "tihiy-syuzhet-backup.json")
                    }
                    startActivityForResult(intent, REQ_EXPORT)
                } catch (_: Exception) {
                    pendingBackupExport = null
                    showToast("Не удалось открыть сохранение файла.")
                }
            }
        }

        @JavascriptInterface
        fun importBackup() {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/json"
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivityForResult(intent, REQ_IMPORT)
                } catch (_: Exception) {
                    showToast("Не удалось открыть выбор файла.")
                }
            }
        }

        @JavascriptInterface
        fun copyText(text: String) {
            runOnUiThread {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Тихий сюжет", text))
                showToast("Скопировано")
            }
        }

        @JavascriptInterface
        fun getLicenseText(): String = try {
            assets.open("third_party_notices.txt").bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (_: Exception) {
            "llama.cpp is licensed under the MIT License. The complete notice is in the app source."
        }
    }

    private fun startModelDownload() {
        try {
            val existing = JSONObject(downloadProgressJson())
            val status = existing.optString("status")
            if (status == "running" || status == "pending" || status == "paused") {
                jsCall("onModelDownloadChanged", "")
                return
            }
            val directory = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                ?: throw IOException("Недоступно хранилище загрузок")
            if (!directory.exists() && !directory.mkdirs()) throw IOException("Не удалось создать папку загрузки")
            val target = File(directory, MODEL_FILE_NAME)
            if (isValidDownloadedModel(target)) {
                prefs.edit().putString(KEY_MODEL_PATH, target.absolutePath).remove(KEY_DOWNLOAD_ERROR).apply()
                jsCall("onModelDownloadChanged", "")
                showToast("Модель уже скачана и проверена.")
                return
            }
            val previousId = prefs.getLong(KEY_DOWNLOAD_ID, -1L)
            if (previousId >= 0) try { downloadManager.remove(previousId) } catch (_: Exception) { }
            prefs.edit().remove(KEY_DOWNLOAD_ID).remove(KEY_DOWNLOAD_ERROR).remove(KEY_MODEL_LOAD_ERROR).apply()
            if (target.exists()) target.delete()
            val freeBytes = StatFs(directory.absolutePath).availableBytes
            if (freeBytes < MODEL_SIZE_BYTES + 96L * 1024L * 1024L) {
                throw IOException("Нужно не менее 1,1 ГБ свободного места")
            }
            val request = DownloadManager.Request(Uri.parse(MODEL_URL)).apply {
                setTitle("Загрузка локальной языковой модели")
                setDescription("Qwen2.5 1.5B · Q4_K_M · около 986 МБ")
                setMimeType("application/octet-stream")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI)
                setAllowedOverMetered(false)
                setAllowedOverRoaming(false)
                setDestinationInExternalFilesDir(this@MainActivity, Environment.DIRECTORY_DOWNLOADS, MODEL_FILE_NAME)
            }
            val id = downloadManager.enqueue(request)
            prefs.edit().putLong(KEY_DOWNLOAD_ID, id).remove(KEY_DOWNLOAD_ERROR).apply()
            jsCall("onModelDownloadChanged", "")
            showToast("Загрузка началась. Можно продолжать пользоваться приложением.")
        } catch (e: Exception) {
            val message = e.message ?: "Проверь подключение к Wi‑Fi и свободное место."
            prefs.edit().putString(KEY_DOWNLOAD_ERROR, message).apply()
            jsCall("onModelDownloadChanged", "")
            showToast("Не удалось начать загрузку модели: $message")
        }
    }

    private fun cancelModelDownload() {
        val id = prefs.getLong(KEY_DOWNLOAD_ID, -1L)
        if (id >= 0) {
            try { downloadManager.remove(id) } catch (_: Exception) { }
        }
        downloadFile().delete()
        prefs.edit().remove(KEY_DOWNLOAD_ID).remove(KEY_DOWNLOAD_ERROR).apply()
        jsCall("onModelDownloadChanged", "")
    }

    private fun downloadFile(): File {
        val directory = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: File(filesDir, "downloads")
        if (!directory.exists()) directory.mkdirs()
        return File(directory, MODEL_FILE_NAME)
    }

    private fun hasGgufHeader(file: File): Boolean = try {
        file.inputStream().use { input ->
            val magic = ByteArray(4)
            input.read(magic) == 4 && magic.contentEquals("GGUF".toByteArray(Charsets.US_ASCII))
        }
    } catch (_: Exception) { false }

    private fun modelFileProblem(file: File): String? {
        if (!file.exists()) return "Файл модели не найден. Попробуй скачать его заново."
        if (!file.isFile || !file.canRead()) return "Файл модели недоступен для чтения. Импортируй или скачай его заново."
        if (file.length() <= MIN_MODEL_BYTES) return "Файл модели пустой или слишком мал. Скачай GGUF заново."
        if (!hasGgufHeader(file)) return "Файл не начинается с заголовка GGUF. Возможно, загрузка повреждена; скачай модель заново."
        if (file.absolutePath == downloadFile().absolutePath && file.length() != MODEL_SIZE_BYTES) {
            return "Размер загруженной Qwen не совпадает: ${file.length()} байт вместо $MODEL_SIZE_BYTES. Удали файл и скачай модель заново."
        }
        return null
    }

    private fun isValidDownloadedModel(file: File): Boolean =
        file.absolutePath == downloadFile().absolutePath && modelFileProblem(file) == null

    private fun selectedModelFile(): File? {
        val path = prefs.getString(KEY_MODEL_PATH, null) ?: return null
        val file = File(path)
        return file.takeIf { modelFileProblem(it) == null }
    }

    private fun modelInfoJson(): String {
        val progress = try { JSONObject(downloadProgressJson()) } catch (_: Exception) { JSONObject() }
        val path = prefs.getString(KEY_MODEL_PATH, null)
        val candidate = path?.let { File(it) }
        val file = selectedModelFile()
        val out = JSONObject()
        out.put("available", file != null)
        out.put("name", file?.name ?: candidate?.name ?: "")
        out.put("size", file?.length() ?: candidate?.takeIf { it.exists() }?.length() ?: 0L)
        out.put("modelError", candidate?.let { modelFileProblem(it) } ?: "")
        out.put("loadError", prefs.getString(KEY_MODEL_LOAD_ERROR, "") ?: "")
        out.put("downloading", listOf("running", "pending", "paused").contains(progress.optString("status")))
        out.put("progress", progress.optDouble("progress", 0.0))
        return out.toString()
    }

    private fun downloadProgressJson(): String {
        val id = prefs.getLong(KEY_DOWNLOAD_ID, -1L)
        if (id < 0) {
            val error = prefs.getString(KEY_DOWNLOAD_ERROR, null)
            return if (!error.isNullOrBlank()) {
                JSONObject().put("status", "failed").put("reasonText", error).toString()
            } else JSONObject().put("status", "idle").toString()
        }
        var cursor: Cursor? = null
        try {
            cursor = downloadManager.query(DownloadManager.Query().setFilterById(id))
            if (cursor == null || !cursor.moveToFirst()) {
                val error = prefs.getString(KEY_DOWNLOAD_ERROR, null)
                return if (!error.isNullOrBlank()) JSONObject().put("status", "failed").put("id", id).put("reasonText", error).toString()
                else JSONObject().put("status", "idle").put("id", id).toString()
            }
            val status = cursor.intColumn(DownloadManager.COLUMN_STATUS)
            val downloaded = cursor.longColumn(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
            val total = cursor.longColumn(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            val reason = cursor.intColumn(DownloadManager.COLUMN_REASON)
            var customReasonText = ""
            val statusName = when (status) {
                DownloadManager.STATUS_PENDING -> "pending"
                DownloadManager.STATUS_RUNNING -> "running"
                DownloadManager.STATUS_PAUSED -> "paused"
                DownloadManager.STATUS_SUCCESSFUL -> {
                    val file = downloadFile()
                    if (isValidDownloadedModel(file)) {
                        prefs.edit().putString(KEY_MODEL_PATH, file.absolutePath).remove(KEY_DOWNLOAD_ERROR).apply()
                        "complete"
                    } else {
                        customReasonText = modelFileProblem(file) ?: "Скачанный файл Qwen не прошёл проверку целостности. Повтори загрузку."
                        prefs.edit().putString(KEY_DOWNLOAD_ERROR, customReasonText).apply()
                        "failed"
                    }
                }
                DownloadManager.STATUS_FAILED -> "failed"
                else -> "idle"
            }
            val percent = if (total > 0) (downloaded.toDouble() * 100.0 / total).coerceIn(0.0,100.0) else 0.0
            return JSONObject().apply {
                put("id", id)
                put("status", statusName)
                put("downloaded", downloaded)
                put("total", total)
                put("progress", percent)
                put("reason", reason)
                put("reasonText", customReasonText.ifBlank { downloadReasonText(status, reason) })
            }.toString()
        } catch (e: Exception) {
            val message = e.message ?: "Не удалось проверить состояние загрузки."
            return JSONObject().put("status", "failed").put("id", id).put("error", message).put("reasonText", message).toString()
        } finally {
            cursor?.close()
        }
    }

    private fun downloadReasonText(status: Int, reason: Int): String = when (status) {
        DownloadManager.STATUS_PENDING -> "Загрузка стоит в очереди Android; обычно она запускается через несколько секунд. Проверь уведомление «Загрузки», если ожидание затянулось."
        DownloadManager.STATUS_PAUSED -> when (reason) {
            DownloadManager.PAUSED_QUEUED_FOR_WIFI -> "Android ждёт немеренную Wi‑Fi: текущая сеть помечена как лимитная. Подключись к другой Wi‑Fi или отключи для этой сети режим «лимитная» в её настройках."
            DownloadManager.PAUSED_WAITING_FOR_NETWORK -> "Нет подходящей Wi‑Fi-сети. Подключись к Wi‑Fi; мобильная сеть для этой загрузки не используется."
            DownloadManager.PAUSED_WAITING_TO_RETRY -> "Связь прервалась. Android автоматически повторит попытку; проверь подключение к Wi‑Fi."
            DownloadManager.PAUSED_UNKNOWN -> "Android временно приостановил загрузку. Проверь Wi‑Fi и уведомление «Загрузки»."
            else -> "Android приостановил загрузку (код причины $reason). Проверь Wi‑Fi и свободное место."
        }
        DownloadManager.STATUS_FAILED -> when (reason) {
            DownloadManager.ERROR_INSUFFICIENT_SPACE -> "На телефоне закончилось место. Освободи не менее 1,1 ГБ и попробуй снова."
            DownloadManager.ERROR_DEVICE_NOT_FOUND -> "Хранилище недоступно. Проверь свободное место и доступность памяти телефона, затем попробуй снова."
            DownloadManager.ERROR_FILE_ERROR -> "Android не смог записать файл. Проверь свободное место и попробуй скачать заново."
            DownloadManager.ERROR_CANNOT_RESUME -> "Android не смог продолжить прерванную загрузку. Повтори загрузку с начала."
            DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "Сервер вернул слишком много перенаправлений. Попробуй снова позже или импортируй GGUF-файл вручную."
            DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "Сервер отклонил запрос или временно недоступен. Проверь сеть и попробуй снова позже."
            DownloadManager.ERROR_HTTP_DATA_ERROR -> "Данные пришли с ошибкой. Проверь Wi‑Fi и попробуй скачать заново."
            DownloadManager.ERROR_UNKNOWN -> "Android не смог завершить загрузку. Проверь Wi‑Fi и свободное место, затем попробуй снова."
            else -> "Android завершил загрузку с ошибкой (код $reason). Проверь сеть и свободное место, затем попробуй снова."
        }
        else -> ""
    }

    private fun Cursor.intColumn(name: String): Int {
        val index = getColumnIndex(name)
        return if (index >= 0) getInt(index) else 0
    }

    private fun Cursor.longColumn(name: String): Long {
        val index = getColumnIndex(name)
        return if (index >= 0) getLong(index) else 0L
    }

    private fun queryDisplayName(uri: Uri): String {
        var result = "imported-model.gguf"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && cursor.moveToFirst()) result = cursor.getString(index) ?: result
        }
        return result
    }

    private fun importModel(uri: Uri) {
        scope.launch(Dispatchers.IO) {
            try {
                val originalName = queryDisplayName(uri)
                val safeBase = originalName.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val filename = if (safeBase.endsWith(".gguf", ignoreCase = true)) safeBase else "$safeBase.gguf"
                val directory = File(filesDir, "models").apply { mkdirs() }
                var expectedSize = -1L
                contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (sizeIndex >= 0 && cursor.moveToFirst()) expectedSize = cursor.getLong(sizeIndex)
                }
                val free = StatFs(filesDir.absolutePath).availableBytes
                if (expectedSize > 0 && free < expectedSize + 64L * 1024L * 1024L) {
                    throw IOException("Недостаточно свободного места для копии модели")
                }
                val target = File(directory, filename)
                val temp = File(directory, "$filename.part")
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(temp).use { output ->
                        val buffer = ByteArray(1024 * 1024)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            output.write(buffer, 0, count)
                        }
                        output.fd.sync()
                    }
                } ?: throw IOException("Не удалось прочитать файл")
                if (temp.length() <= MIN_MODEL_BYTES) {
                    temp.delete()
                    throw IOException("Файл слишком мал или пуст")
                }
                if (!hasGgufHeader(temp)) {
                    temp.delete()
                    throw IOException("Файл не начинается с заголовка GGUF")
                }
                if (target.exists()) target.delete()
                if (!temp.renameTo(target)) {
                    temp.copyTo(target, overwrite = true)
                    temp.delete()
                }
                prefs.edit().putString(KEY_MODEL_PATH, target.absolutePath).remove(KEY_MODEL_LOAD_ERROR).apply()
                activeSessionKey = null
                runOnUiThread {
                    jsCall("onModelImported", target.name)
                    showToast("Модель сохранена в приложении.")
                }
            } catch (e: Exception) {
                runOnUiThread { showToast("Импорт не удался: ${e.message ?: "ошибка файла"}") }
            }
        }
    }

    private fun exportBackup(uri: Uri) {
        val content = pendingBackupExport ?: return
        pendingBackupExport = null
        scope.launch(Dispatchers.IO) {
            try {
                contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) }
                    ?: throw IOException("Не удалось открыть файл")
                runOnUiThread { showToast("Резервная копия сохранена.") }
            } catch (e: Exception) {
                runOnUiThread { showToast("Не удалось записать копию: ${e.message ?: "ошибка"}") }
            }
        }
    }

    private fun importBackup(uri: Uri) {
        scope.launch(Dispatchers.IO) {
            try {
                val data = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: throw IOException("Не удалось открыть файл")
                runOnUiThread { jsCall("onBackupLoaded", data) }
            } catch (e: Exception) {
                runOnUiThread { showToast("Не удалось прочитать копию: ${e.message ?: "ошибка"}") }
            }
        }
    }

    private fun jsCall(function: String, vararg values: String) {
        if (!::webView.isInitialized) return
        val quoted = values.joinToString(",") { JSONObject.quote(it) }
        webView.post { webView.evaluateJavascript("window.$function && window.$function($quoted);", null) }
    }

    private fun showToast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    }

    @Deprecated("Uses document-picker callbacks for compatibility with Android 8+")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_AVATAR) {
            val uri = if (resultCode == RESULT_OK) data?.data else null
            avatarCallback?.onReceiveValue(uri?.let { arrayOf(it) })
            avatarCallback = null
            return
        }
        if (resultCode != RESULT_OK || data?.data == null) {
            if (requestCode == REQ_EXPORT) pendingBackupExport = null
            return
        }
        when (requestCode) {
            REQ_MODEL -> importModel(data.data!!)
            REQ_IMPORT -> importBackup(data.data!!)
            REQ_EXPORT -> exportBackup(data.data!!)
        }
    }

    override fun onDestroy() {
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            systemBackCallback?.let { onBackInvokedDispatcher.unregisterOnBackInvokedCallback(it) }
        }
        super.onDestroy()
    }

    @Deprecated("The back button is routed to the WebView's current screen or modal first")
    override fun onBackPressed() {
        dispatchSystemBack()
    }

    private fun dispatchSystemBack() {
        if (!::webView.isInitialized) { finish(); return }
        if (backPressPending) return
        backPressPending = true
        webView.evaluateJavascript(
            "(function(){return typeof window.handleSystemBack === 'function' ? window.handleSystemBack() : false;})()"
        ) { handled ->
            backPressPending = false
            if (handled != "true") finish()
        }
    }

    companion object {
        private const val PREFS = "tihiy-local-settings"
        private const val KEY_MODEL_PATH = "selected-model-path"
        private const val KEY_DOWNLOAD_ID = "download-manager-id"
        private const val KEY_DOWNLOAD_ERROR = "download-last-error"
        private const val KEY_MODEL_LOAD_ERROR = "model-load-last-error"
        private const val REQ_AVATAR = 4101
        private const val REQ_MODEL = 4102
        private const val REQ_EXPORT = 4103
        private const val REQ_IMPORT = 4104
        private const val MODEL_FILE_NAME = "Qwen2.5-1.5B-Instruct-Q4_K_M.gguf"
        private const val MODEL_SIZE_BYTES = 986_048_768L
        private const val MIN_MODEL_BYTES = 1L * 1024L * 1024L
        private const val MODEL_URL = "https://huggingface.co/bartowski/Qwen2.5-1.5B-Instruct-GGUF/resolve/9eadc66189c7641e1ddd226b8267a9119b2ce2d4/Qwen2.5-1.5B-Instruct-Q4_K_M.gguf"
    }
}
