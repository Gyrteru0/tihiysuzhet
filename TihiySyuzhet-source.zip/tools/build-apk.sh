#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
COMMIT="$(tr -d '\r\n' < "$ROOT/LLAMA_CPP_COMMIT.txt")"
LLAMA="$ROOT/third_party/llama.cpp"
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/.cache/android-sdk}}"
NDK="$SDK/ndk/29.0.13113456"
BUILD_TOOLS="$SDK/build-tools/36.0.0"

if [[ -z "${JAVA_HOME:-}" ]]; then
  JAVA_BIN="$(command -v java || true)"
  if [[ -n "$JAVA_BIN" ]]; then JAVA_HOME="$(cd "$(dirname "$JAVA_BIN")/.." && pwd)"; export JAVA_HOME; fi
fi
if [[ -z "${JAVA_HOME:-}" || ! -x "$JAVA_HOME/bin/java" ]]; then
  echo "JDK 17+ is required. Set JAVA_HOME before building." >&2
  exit 2
fi
if [[ ! -d "$SDK/platforms/android-36" || ! -d "$NDK" || ! -x "$BUILD_TOOLS/apksigner" ]]; then
  echo "Android SDK API 36, NDK 29.0.13113456 and Build Tools 36 are required at $SDK." >&2
  exit 2
fi
export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"

if [[ ! -f "$LLAMA/CMakeLists.txt" ]]; then
  echo "Fetching llama.cpp at pinned revision $COMMIT ..."
  mkdir -p "$LLAMA"
  if ! git -C "$LLAMA" rev-parse --git-dir >/dev/null 2>&1; then git -C "$LLAMA" init -q; fi
  if git -C "$LLAMA" remote get-url origin >/dev/null 2>&1; then
    git -C "$LLAMA" remote set-url origin https://github.com/ggml-org/llama.cpp.git
  else
    git -C "$LLAMA" remote add origin https://github.com/ggml-org/llama.cpp.git
  fi
  git -C "$LLAMA" fetch --depth 1 origin "$COMMIT"
  git -C "$LLAMA" checkout --detach FETCH_HEAD
fi

cd "$ROOT"
./gradlew --no-daemon -PllamaSrc="$LLAMA" :app:assembleDebug

# The Android Gradle plugin keeps large debug symbols in the llama.cpp .so files
# in some NDK versions. Strip only DWARF/debug symbols, preserve dynamic symbols,
# align native libraries, then sign the installable APK with the normal debug key.
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
PAYLOAD="$TMP/payload"
mkdir -p "$PAYLOAD"
unzip -q "$ROOT/app/build/outputs/apk/debug/app-debug.apk" -d "$PAYLOAD"
STRIP="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip"
if [[ ! -x "$STRIP" ]]; then echo "llvm-strip not found in the selected NDK." >&2; exit 2; fi
while IFS= read -r -d '' library; do
  "$STRIP" --strip-debug "$library"
done < <(find "$PAYLOAD/lib" -type f -name '*.so' -print0)
if [[ -d "$PAYLOAD/META-INF" ]]; then
  find "$PAYLOAD/META-INF" -type f \( -iname '*.RSA' -o -iname '*.SF' -o -iname '*.DSA' -o -iname '*.EC' \) -delete
fi
(cd "$PAYLOAD" && zip -q -0 -X -r "$TMP/unsigned.apk" .)
"$BUILD_TOOLS/zipalign" -f -p 4 "$TMP/unsigned.apk" "$TMP/aligned.apk"
mkdir -p "$HOME/.android"
if [[ ! -f "$HOME/.android/debug.keystore" ]]; then
  "$JAVA_HOME/bin/keytool" -genkeypair -keystore "$HOME/.android/debug.keystore" -storepass android \
    -alias androiddebugkey -keypass android -dname "CN=Android Debug,O=Android,C=US" \
    -keyalg RSA -keysize 2048 -validity 10000 >/dev/null 2>&1
fi
"$BUILD_TOOLS/apksigner" sign --ks "$HOME/.android/debug.keystore" --ks-key-alias androiddebugkey \
  --ks-pass pass:android --key-pass pass:android --out "$ROOT/TihiySyuzhet.apk" "$TMP/aligned.apk"
"$BUILD_TOOLS/apksigner" verify "$ROOT/TihiySyuzhet.apk"
"$BUILD_TOOLS/zipalign" -c 4 "$ROOT/TihiySyuzhet.apk"

echo
echo "APK ready: $ROOT/TihiySyuzhet.apk"
